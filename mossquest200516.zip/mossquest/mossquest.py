#Coded by Owen Payette McGarry, Somerville, Massachusetts, 2019
#Writing by Owen Payette McGarry and Sophie Griswold
#Illustration by Owen Payette McGarry with assistance from Elena Brunner
#
#Beta testing by Paula Pino, Elena Brunner, Christopher Stock


import easygui
from pygame import mixer # Load the required library https://www.pygame.org/docs/ref/music.html
mixer.init()
mixer.music.load('audio/soundtrack.mp3') #will be replaced with a composition by Adam?
mixer.music.play(loops=-1)

#Assorted variables 
version = 200516

moss = 0 #total score
lookcreature = 0 #1 - you begin to see the creatures everywhere.
vultures = 2
bird = 0
smokes = 0
smokesinv = ""
snails = 0
snailsinv = ""
penguininv = "" #tied to penguinquest
diaper = 0
diaperinv = ""
incantationinv = "" #tied to loudandy == 1
rat = 0
ratinv = ""
apple = 0
appleinv = ""
tisdale = 0
tisdaleinv = ""
map = 1
mapinv = ""
snowshoes = 1
snowshoesinv = ""
chum = 0
chuminv = ""
coldone = 0
coldoneinv = ""
guz = 0
guzinv = ""
gus = 0
gusinv = ""
egg = 0
egginv = ""
branch = 0
branchinv = ""
gregberries = 0
gregberriesinv = ""

#mosses
gcmoss = 0 #Gundy's Carpet
gcmossinv = ""
bdmoss = 0 #Bryologist's Dream
bdmossinv = ""
dpmoss = 0 #Diaper Peat
dpmossinv = ""
bsmoss = 0 #Brundled Sphagnum
bsmossinv = ""
gsmoss = 0 #Giuseppe's Shag
gsmossinv = ""
mpdmoss = 0 #Mudpuppy's duvet
mpdmossinv = ""
rdmoss = 0 #Reindeer moss
rdmossinv = ""
pmlwmoss = 0 #Parrotman's Liverwort
pmlwmossinv = ""
bbmoss = 0 #Bungled Brown
bbmossinv = ""
stmoss = 0 #Smolensk Tea
stmossinv = ""
bbrmoss = 0 #Bushman's Bogroll - not yet placed
bbrmossinv = ""
blmoss = 0 #Burpo's Liverwort
blmossinv = ""
prmoss = 0 #Poupe Rot
prmossinv = ""

#quests
loudandy = 0 #0 - not started, 1 - have incantation, 2 - completed
tla = 1 #rotating "talk loud andy" responses
diaperquest = 0 #1 - completed
penguinquest = 0 #0 - not started, 1 - given sack, 2 - penguin caught, 3 - quest completed
deathquest = 0

#beginning game setup
roomx = 4
roomy = 1
lastmove = ("You pull your crude boat onto the rocky shores of the town of Mossfell, on the tip of the Keller Penninsula.  The wharf is quiet.  Jaw set, you think ruefully of your hungering sheep, for whom you have undertaken this thankless quest.  The sheep's sustenance - the moss on your small island - has browned and shriveled.  You seek greener cultivars with which to repopulate your barren croft.  A dismal wind blows.\n\nWelcome to Moss Quest v. {}; a production of Sophie Griswold and Owen Payette McGarry.\n\nEnter your first command, or type HELP for assistance.").format(version)
lastimage = "images/mossquest.gif"
play = 1 #This makes the game loop




################################################################################

while play == 1:
	if play == 0: #if player quits
		break
		

########## This is the big boy, everything filters into this command ##########	
	usrcmd = easygui.enterbox(lastmove, image=lastimage) 
	
#	Navigation
	if usrcmd.lower() == ("go north") and snowshoes == 1:
		if roomy >= 6:
			usrcmd = "direrrnorth"
		else:
			roomy = roomy+1
			usrcmd = "look"
			
	elif usrcmd.lower() == ("go north") and snowshoes != 1:
		if roomy >= 3:
			usrcmd = "direrrbog"
		else:
			roomy = roomy+1
			usrcmd = "look"
		
		
	elif usrcmd.lower() == ("go south"):
		if roomy <= 1:
			usrcmd = "direrrsouth"
		else:
			roomy = roomy-1
			usrcmd = "look"
		

	elif usrcmd.lower() == ("go east"):
		if roomx >= 4:
			usrcmd = "direrreast"
		else:
			roomx = roomx+1
			usrcmd = "look"

		
	elif usrcmd.lower() == ("go west"):
		if roomx <= 1:
			usrcmd = "direrrwest"
		else:
			roomx = roomx-1	
			usrcmd = "look"	



########## y1 ##########
#	
#Room x1, y1: Mt. Vernon 		
	if usrcmd.lower() == ("look") and roomx == 1 and roomy == 1:
		lastmove = "MT. VERNON stands before you, looking alien in the sinister tundra, a relic of a bygone world.  By necessity, many years ago, the CUPOLA was transformed into a lighthouse to guide ships in Admiralty bay.  The Lighthouse KEEPER scrapes idly at the dead, rocky soil with a hoe."
		lastimage = "images/mtvernon.gif"	
		
	elif usrcmd.lower() == ("map") and roomx == 1 and roomy == 1 and map == 1 or usrcmd.lower() == ("look map") and roomx == 1 and roomy == 1 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x1y1.gif"	

	elif usrcmd.lower() == ("look mt vernon") and roomx == 1 and roomy == 1 or usrcmd.lower() == ("look mt. vernon") and roomx == 1 and roomy == 1:
		lastmove = "In a paroxism of patriotism, the last Fossil Fuel Congress had the former house of George Washington shipped here, as an unintentionally ironic monument to American exceptionalism.  The interior has been throughly scavenged, and stripped down to the studs.  The lighthouse KEEPER who lives in the attic, has filled the ground floor with pestilential ceramic vats of CHUM that he sells to passing fishermen."

	elif usrcmd.lower() == ("look cupola") and roomx == 1 and roomy == 1:
		lastmove = "The delicate window panes you saw in a book in your Ma's library have been replaced with fresnel lenses scavenged from flooded lighthouses in the north."

	elif usrcmd.lower() == ("look chum") and roomx == 1 and roomy == 1:
		lastmove = "The ground floor is scattered with large earthenwear jugs filled with abyssmal quantities of unspeakable vicera.  Black clouds of flies gush from the mouths of the jugs."

	elif usrcmd.lower() == ("get chum") and roomx == 1 and roomy == 1 and chum != 1:
		lastmove = "You dip your hand into the churning turgid mass of fish entrails, and come up with a handful which you place in your pocket for later.  CHUM is added to your INVENTORY."
		chum = 1
		
	elif usrcmd.lower() == ("get chum") and roomx == 1 and roomy == 1 and chum == 1:
		lastmove = "You already have a fistful of CHUM in your INVENTORY."

	elif usrcmd.lower() == ("look keeper") and roomx == 1 and roomy == 1:
		lastmove = "Señor Engorgio, the lighthouse KEEPER works idly around MT. VERNON.  He is able-bodied, but salt has brined his tanned, weatherbeaten face rendering his age indeterminate.  He puffs steadily on a pipe, and a bit of ash blows into his bulky, cableknit sweater."
		
	elif usrcmd.lower() == ("talk keeper") and roomx == 1 and roomy == 1 and apple != 2:
		lastmove = "He pauses his idle work and leans upon his tool.  Señor Engorgio's English is still timid after these many years.  He explains that he has been trying to start an apple orchard to the north of MT. VERNON, but needs more apple seeds."

	elif usrcmd.lower() == ("talk keeper") and roomx == 1 and roomy == 1 and apple == 2:
		lastmove = "He pauses his idle work and leans upon his tool.  Señor Engorgio's English is still timid after these many years.  He thanks you for the apple, he hopes that one of those seeds may take to the harsh environment."
	
	elif usrcmd.lower() == ("give apple") and roomx == 1 and roomy == 1 and apple == 1:
		lastmove = "You produce your bruised apple and relinquish it to the lighthouse KEEPER.  Taking it, he evicerates the fruit with his blunt thumbnails, and holds a seed up to the lighthouse's light.  He emits tones of gruff contentment.  He hands you a sheet of moss, and mimes wiping his ass with it.  BUSHMAN'S BOGROLL added to your INVENTORY."
		apple = 2
		bbrmoss = 1
		moss = moss + 1
	
	elif usrcmd.lower() == ("give apple") and roomx == 1 and roomy == 1 and apple == 0:
		lastmove = "You don't have any apple to give, you fool."
		
	elif usrcmd.lower() == ("give apple") and roomx == 1 and roomy == 1 and apple == 2:
		lastmove = "You already gave away your apple."
		
	elif usrcmd.lower() == ("look admiralty bay") and roomx == 1 and roomy ==1 or usrcmd.lower() == ("look bay") and roomx == 1 and roomy ==1:
		lastmove = "Looks wet."
		



#		
#		
#Room x2, y1 		Gruelmonger
	elif usrcmd.lower() == ("look") and roomx == 2 and roomy ==1 and gregberries != 1:
		lastmove = "Along the side of the main road a GRUELMONGER stirs an unappetizing pot of GRUEL with a whalebone spurtle.  He shouts out to you, promoting his goods."
		lastimage = "images/gruelmonger.gif"
		
	elif usrcmd.lower() == ("look") and roomx == 2 and roomy ==1 and gregberries == 1:
		lastmove = "Along the side of the main road a GRUELMONGER stirs an unappetizing pot of GRUEL with a whalebone spurtle.  He stops you to ask about the contents of your pockets."
		lastimage = "images/gruelmonger.gif"
		
	elif usrcmd.lower() == ("map") and roomx == 2 and roomy ==1 and map == 1 or usrcmd.lower() == ("look map") and roomx == 2 and roomy ==1 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x2y1.gif"	

	elif usrcmd.lower() == ("look gruelmonger") and roomx == 2 and roomy == 1:
		lastmove = "He notices your consideration and flourishes the dripping end of his spurtle in your direction in the hopes the questionably-edible odor will recommend the product. He wears a GRUEL spattered smock beneath a threadbare shawl, he cries out; enumerating the merits of his ware so earnestly that he foams at the mouth.  He clasps his hands together and appeals obsequiously."
		
	elif usrcmd.lower() == ("talk gruelmonger") and roomx == 2 and roomy == 1 and gregberries == 0:
		lastmove = """The GRUELMONGER entreats you to purchase some GRUEL, "If this isn’t the finest streetgruel, so warm and hearty, on all of King George Island, our verdant haven, then I wish you to parade me through the streets for the rest of my days, in haircloth and shame, and until I can't speak I'll proclaim: I have misrepresented the quality of my GRUEL and I am lower than dirt for this transgression.” He is now down on his knees, groveling in wild supplication, "I stand by the quality of my GRUEL, so flavorful and wet, and I hope it is seen that this simple truth oozes out of my very pores, my conviction is so strong. In fact. If this GRUEL doesn’t slide down your throat with the wholesome enrichment of one of Jesus’ very turds, so pure and holy, then you should rend my personal chest open and pour the blood from my bursting heart into the trough, that it may provide the dimension of flavor you found lacking." """

	elif usrcmd.lower() == ("talk gruelmonger") and roomx == 2 and roomy == 1 and gregberries == 1:
		lastmove = """The GRUELMONGER sniffs in your direction.  "Excuse me kind stranger, do you perchance have any gregberries about your good person? I believe that I detect a whiff of them, so tart and flavorsome, on your person, so kind and generous.  I could make you an admirable exchange; for the gregberries add a piquantness that is extremely desirable for a balanced GRUEL."""
	
	elif usrcmd.lower() == ("talk gruelmonger") and roomx == 2 and roomy == 1 and gregberries == 2:
		lastmove = """The GRUELMONGER entreats you to purchase some of his improved GRUEL, "If this, my pawpaw's recipe, isn’t the finest streetgruel, so warm and hearty, on all of King George Island, our humble refuge, then I implore you to take up my own personal spurtle, passed down from my forebears, and beat me until blood foams forth from my mouth and my teeth are scattered about the cobblestones and my ribs are cracked and broken beneath my unworthy skin.  Then I wish you to continue to strike me until my body is an unrecognizable mass of pulpy meat that foul flies will investigate only once their supplies of filth and garbage is dwindling.  Then you should paint the walls with my blood to the effect that this man has misrepresented the quality of his GRUEL.” """
		
	elif usrcmd.lower() == ("give gregberries") and roomx == 2 and roomy == 1 and gregberries == 1:
		lastmove = """You extend your meager fistful of berries and the GRUELMONGER falls to his knees sobbing, genuflecting at your feet.  "Oh, thank you, thank you, compassionate benefactor! I can now brew my GRUEL just like pawpaw used to make it, so rich and zesty, so tangy and savory, so unctious and nourishing..." He continued on, but presented you with a bundle of moss produced from his smock. BUSHMAN'S BOG ROLL has been added to your INVENTORY"""
		gregberries = 2
		bbrmoss = 1
		moss = moss + 1
		
	
	elif usrcmd.lower() == ("look gruel") and roomx == 2 and roomy == 1 and gregberries != 2:
		lastmove = "It looks thin and so limpid that you gather it's uncointaminated by nourishment.  Though it does have an alarmingly bitter bouquet."
		
	elif usrcmd.lower() == ("look gruel") and roomx == 2 and roomy == 1 and gregberries == 2:
		lastmove = "The addition of the gregberries has made a marked improvement to the color and odor of the broth."
		
	elif usrcmd.lower() == ("get gruel") and roomx == 2 and roomy == 1 and gregberries != 2:
		lastmove = "You don't really have the stomach for it right now."
		
	elif usrcmd.lower() == ("get gruel") and roomx == 2 and roomy == 1 and gregberries == 2:
		lastmove = "You still don't think it's a great idea, even in its improved state."
		
	
#		
#		
#Room x3, y1 Death's door
	elif usrcmd.lower() == ("look") and roomx == 3 and roomy ==1 and tisdale != 2:
		lastmove = ("You stand outside the stained beige entryway to Death's Door Retirement Home.  Within, the RECEPTIONIST intently probes the moist depths of her nose.  Several gaunt, pallid SENIORS sit stiffly around a card table gumming dry, falvorless cod.  A figure bobs placidly in a burbling a HYDROPONIC TANK.  Outside, {} VULTURES circle overhead, biding their time.").format(vultures)
		lastimage = "images/deathsdoor.gif"
		
	elif usrcmd.lower() == ("map") and roomx == 3 and roomy ==1 and map == 1 or usrcmd.lower() == ("look map") and roomx == 3 and roomy ==1 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x3y1.gif"	

		
	elif usrcmd.lower() == ("look") and roomx == 3 and roomy ==1 and tisdale == 2:
		lastmove = "You stand outside the stained beige entryway to Death's Door Retirement Home.  Within, the RECEPTIONIST intently probes the moist depths of her nose.  Several gaunt, pallid SENIORS sit stiffly around a card table gumming dry, falvorless cod.  A figure bobs placidly in a burbling HYDROPONIC TANK."
		lastimage = "images/deathsdoor.gif"

	elif usrcmd.lower() == ("look receptionist") and roomx == 3 and roomy ==1:
		lastmove = "She sits behind the front desk of the retirement home, a rubinesque character with oversized glasses and an oversize green cardigan that make her look like some kind of gross bug. She taps idly at the keyboard in front of her."	
		
	elif usrcmd.lower() == ("talk receptionist") and roomx == 3 and roomy ==1 and tisdale != 2:
		lastmove = """The RECEPTIONIST leans in and says in a hushed tone, "Mrs. Tisdale was out front talking a stroll when she disappeared last week, left her walker and vanished!" A wad of green mucosa flies from her finger as she gesticulates. "Would you see if you can find her." """
	
	elif usrcmd.lower() == ("talk receptionist") and roomx == 3 and roomy ==1 and tisdale == 2:
		lastmove = "“Look’s like you’ve found her, and sent those dastardly birds away!” Says the receptionist, peering at the now vulture-free sky. “Take this APPLE as a token of my appreciation and a big thank you from our seniors!” She pats you on the head, you add the APPLE to your INVENTORY."
		apple = 1
		
	elif usrcmd.lower() == ("look hydroponic tank") and roomx == 3 and roomy ==1:
		lastmove = "A polished plaque informs you that the wreched creature within is Gordon St. Claire of Duluth, born over 200 years ago.  Fluids pump vicerally through clear tubes into his nearly featureless form.  His skin gentely billows, amorphously."
		
	elif usrcmd.lower() == ("talk hydroponic tank") and roomx == 3 and roomy ==1:
		lastmove = "Lost in retrospection of our past catastrophe, you wish you could ask the floating figure about the old world which you've never seen, but you've been informed that he's effectively nonverbal, as well as blind, and deaf, aside from hardly having two brain cells to rub together."

	elif usrcmd.lower() == ("look seniors") and roomx == 3 and roomy ==1:
		lastmove = "With vacant eyes they huff dryly through their nearly translucent, papery lips.  Their skin looks like wax.  They tremble.  They emnit a faint odor of warm canned tuna.  But something about them reminds you of your gentle mother Gurtha, no doubt in her rocking chair at the old croft, knitting interminably."	
		
	elif usrcmd.lower() == ("talk seniors") and roomx == 3 and roomy ==1 and tisdale != 2:
		lastmove = "They moan and huff and wheeze goulishly at you, eyes bulging.  You can not understand their meaning.  One coughs ferociously; clouds of dust plume from his toothless mouth.  You hear the faint tap of a VULTURE at the window."	
	
	elif usrcmd.lower() == ("talk seniors") and roomx == 3 and roomy ==1 and tisdale == 2:
		lastmove = "They moan and huff and wheeze goulishly at you, eyes bulging.  You can not understand their meaning.  One coughs ferociously; clouds of dust plume from his toothless mouth."	
		
	elif usrcmd.lower() == ("look vultures") and roomx == 3 and roomy ==1 and tisdale != 2 or usrcmd.lower() == ("look vulture") and roomx == 3 and roomy ==1 and tisdale != 2 :
		lastmove = "They wheel overhead sinisterly in the remote and awful twilight."
		vultures = vultures * 2
		
	elif usrcmd.lower() == ("talk vultures") and roomx == 3 and roomy ==1 and tisdale != 2 or usrcmd.lower() == ("talk vulture") and roomx == 3 and roomy ==1 and tisdale != 2 :
		lastmove = "They cackle with remarkable vulgarity."
		vultures = vultures * 2
		
	elif usrcmd.lower() == ("look vultures") and roomx == 3 and roomy ==1 and tisdale == 2 or usrcmd.lower() == ("look vulture") and roomx == 3 and roomy ==1 and tisdale == 2 :
		lastmove = "They have all flown off."
		
	elif usrcmd.lower() == ("get vultures") and roomx == 3 and roomy ==1 or usrcmd.lower() == ("get vulture") and roomx == 3 and roomy ==1:
		lastmove = "They are well out of reach"
		
	elif usrcmd.lower() == ("give mrs. tisdale") and roomx == 3 and roomy ==1 and tisdale == 1 or usrcmd.lower() == ("give mrs tisdale") and roomx == 3 and roomy ==1 and tisdale == 1 or usrcmd.lower() == ("give appendage") and roomx == 3 and roomy ==1 and tisdale == 1:
		lastmove = "You drop Mrs. Tisdale’s mummified form before the concrete steps of the retirement home, and immediately notice a shift in the billow and churn of the amassed VULTURES. A vortex of swirling birds descends from the heavens and engulfs the body of the blackened senior before retracting heavenward. The churning flock slowly recedes into the distance, winging towards Mossfell Peak."
		tisdale = 2
		vultures = 0
		
	elif usrcmd.lower() == ("give mrs. tisdale") and roomx == 3 and roomy ==1 and tisdale != 1 or usrcmd.lower() == ("give mrs tisdale") and roomx == 3 and roomy ==1 and tisdale != 1 or usrcmd.lower() == ("give appendage") and roomx == 3 and roomy ==1 and tisdale != 1:
		lastmove = "You don't have a Mrs. Tisdale to give."

	
		
#		
#		
#Room x4, y1 Wharf
	elif usrcmd.lower() == ("look") and roomx == 4 and roomy == 1 and moss <= 4:
		lastmove = "A lone FIGURE stands on the WHARF, scanning the dim horizon over the inky, impenetrable depths of Admiralty Bay.  Your BOAT is safely stowed on the rocky shore."
		lastimage = "images/port.gif"
		
	elif usrcmd.lower() == ("look") and roomx == 4 and roomy == 1 and moss >= 5:
		lastmove = "A large SCHOONER is tied up at the dock.  You recgonise the merhchantman ABSALOMA leaning on the gunwale, smoking what smells astoundingly like tobacco.  A FIGURE stands on the WHARF, scanning the dim horizon over the inky, impenetrable depths of Admiralty Bay.  Your BOAT is safely stowed on the rocky shore."
		lastimage = "images/port.gif"
		
	elif usrcmd.lower() == ("map") and roomx == 4 and roomy == 1 and map == 1 or usrcmd.lower() == ("look map") and roomx == 4 and roomy == 1 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x4y1.gif"	
		
	elif usrcmd.lower() == ("look schooner") and roomx == 4 and roomy == 1 and moss >= 5:
		lastmove = "She is the Clipper Ship David Coverdale of Stromness, one of the few merchant vessels still in existance.  She was a suprizingly sleak ship with a long tapering bow and small, elevated transom, no doubt she was converted from a luxury yacht.  But now her topsides are slate colored and beaten and splintered from rough loading.  Her sails are quilts of canvas in various shades of off-white.  Red stains like blood run down her hull from various pieces of steel hardware."

	elif usrcmd.lower() == ("get schooner") and roomx == 4 and roomy == 1 and moss >= 5:
		lastmove = "Don't be an idiot"
		
	elif usrcmd.lower() == ("look absaloma") and roomx == 4 and roomy == 1 and moss >= 5:
		lastmove = "ABSALOMA is an elderly black Nova Scotian, immediately recognizable in spite of this being your first meeting, for she is an unparalleled seaman who has seen more of the world than most people alive.  She is old, her distended breasts swing around her navel, like tube socks filled with wet meat.  Her skin is mottled and she has weird little tombstone teeth, but she still walks along the deck with the steadiness of a sailor half her age."

	elif usrcmd.lower() == ("talk absaloma") and roomx == 4 and roomy == 1 and moss >= 5:
		lastmove = """You ask her where she is bound for.  "Halifax," she says.  You think she must be jesting, "I will die soon, but I'm afraid, afraid to die beyond the ghoulish mocking of hope on these foreign shores.  My grandmother was born in Halifax, her grandmother was born in Halifax, I was born in Halifax, and I will die in Halifax." You ask her if she has been back since the Great Inconvenience, "Nobody has been back to North America, but I've heard rumors that some survived and now live on guava and coconuts beneath the sultry shade of young fig trees in the old citadel."  She gives a wry smile, you don't believe her. """
		
	
	elif usrcmd.lower() == ("look admiralty bay") and roomx == 4 and roomy ==1 or usrcmd.lower() == ("look bay") and roomx == 4 and roomy ==1:
		lastmove = "Looks wet."
		
	elif usrcmd.lower() == ("look seaweed") and roomx == 4 and roomy ==1:
		lastmove = "You ma used to make a great porrige out of this stuff."

	elif usrcmd.lower() == ("get seaweed") and roomx == 4 and roomy ==1:
		lastmove = "There's plenty of it around the croft."
		
	elif usrcmd.lower() == ("look figure") and roomx == 4 and roomy ==1:
		lastmove = "He is an older man, bowed down with memory, eyes tilled with distended lines of old sadness."
		
	elif usrcmd.lower() == ("talk figure") and roomx == 4 and roomy ==1:
		lastmove = "His voice is weak, he licks his dry lips before talking.  He explains that in the chaos of the Great Inconvenience he was seperated from his wife.  They had planned to seek asylum together in Mossfell, but having been lost he proceeded south without her.  Each day, he waits for her arrival at the port."

	elif usrcmd.lower() == ("look wharf") and roomx == 4 and roomy ==1:
		lastmove = "A small, but sturdy wharf.  Made of stone, with a shaggy mop of seaweed sloshing about the waterline.  You spy several SNAILS plodding along among the weed."
		
	elif usrcmd.lower() == ("look boat") and roomx == 4 and roomy ==1:
		lastmove = "A rude craft, looks like the work of a child.  But your pa was an industrial coatings salesman, not a shipwright.  And despite a slight starboard list, the BOAT has served you well."
		
	elif usrcmd.lower() == ("get boat") and roomx == 4 and roomy ==1:
		lastmove = "Best to leave it here, it may be small, but it's much too heavy to carry about."

	elif usrcmd.lower() == ("look snails") and roomx == 4 and roomy ==1:
		lastmove = "Smug lil slimers."
		
	elif usrcmd.lower() == ("get snails") and roomx == 4 and roomy ==1 and snails == 0:
		lastmove = "You lean over the edge of the wharf and gingerly pick several of the choisest SNAILS from within the algeal slime.  SNAILS added to your INVENTORY."
		snails = 1
		
	elif usrcmd.lower() == ("get snails") and roomx == 4 and roomy ==1 and snails == 1:
		lastmove = "You already have several of the best of those bilious beasts bursting from your bag."

		
		
########## y2 ##########	
#		
#Room x1, y2: Orchard	
	elif usrcmd.lower() == ("look") and roomx == 1 and roomy == 2 and lookcreature == 0 and gus == 0:
		lastmove = """You are surrounded by a haphazard orchard of small dead and dying TREES.  You notice a healthy patch of GUNDY'S CARPET growing up a tree stump.  You hear a curious squonking and honking from one of the trees, and further examination reveals a small green parrot named THE GUS. “THE GUS” says THE GUS atonally."""
		lastimage = "images/orchard.gif"
		
	elif usrcmd.lower() == ("look") and roomx == 1 and roomy == 2 and lookcreature == 0 and gus != 0:
		lastmove = "You are surrounded by a haphazard orchard of small dead and dying TREES.  You notice a healthy patch of GUNDY'S CARPET growing up a tree stump."
		lastimage = "images/orchard.gif"
		
	elif usrcmd.lower() == ("look") and roomx == 1 and roomy == 2 and lookcreature == 1 and gus == 0:
		lastmove = """You are surrounded by a haphazard orchard of small dead and dying TREES.  You notice a healthy patch of GUNDY'S CARPET growing up a tree stump.  Indirectly you see a writhing uneartly blackness among the trees.  You hear a curious squonking and honking from one of the trees, and further examination reveals a small green parrot named THE GUS. “THE GUS” says THE GUS atonally."""
		lastimage = "images/orchard.gif"
		
	elif usrcmd.lower() == ("look") and roomx == 1 and roomy == 2 and lookcreature == 1 and gus != 0:
		lastmove = "You are surrounded by a haphazard orchard of small dead and dying TREES.  You notice a healthy patch of GUNDY'S CARPET growing up a tree stump.  Indirectly you see a writhing uneartly blackness among the trees."
		lastimage = "images/orchard.gif"
		
	elif usrcmd.lower() == ("map") and roomx == 1 and roomy == 2 and map == 1 or usrcmd.lower() == ("look map") and roomx == 1 and roomy == 2 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x1y2.gif"	

	elif usrcmd.lower() == ("look the gus") and roomx == 1 and roomy == 2 and gus == 0:
		lastmove = "You surmise that the birds name is THE GUS from its continued utterances. Its eyes overflow its sockets vulgarly.  Its plumage isn't as vibrant as other parrots you've seen.  It nibbles idly on a nearby branch."
		
	elif usrcmd.lower() == ("look the gus") and roomx == 1 and roomy == 2 and gus == 1:
		lastmove = "THE GUS is in your INVENTORY."
		
	elif usrcmd.lower() == ("look the gus") and roomx == 1 and roomy == 2 and gus >= 2:
		lastmove = "There is no The Gus to look at."
		
	elif usrcmd.lower() == ("talk the gus") and roomx == 1 and roomy == 2 and gus == 0:
		lastmove = """ "THE GUS" Says THE GUS."""
		
	elif usrcmd.lower() == ("talk the gus") and roomx == 1 and roomy == 2 and gus == 1:
		lastmove = "THE GUS is in your INVENTORY."
		
	elif usrcmd.lower() == ("talk the gus") and roomx == 1 and roomy == 2 and gus >= 2:
		lastmove = "There is no The Guz to talk to."
		
	elif usrcmd.lower() == ("get the gus") and roomx == 1 and roomy == 2 and gus == 0:
		lastmove = """You reach one finger towards the bird and say "Step up, THE GUS". The parrot declines the offered finger and takes a seat on your shoulder. THE GUS has been added to your INVENTORY."""
		gus = 1

	elif usrcmd.lower() == ("get the gus") and roomx == 1 and roomy == 2 and gus == 1:
		lastmove = "THE GUS is already in your INVENTORY"
		
	elif usrcmd.lower() == ("get the gus") and roomx == 1 and roomy == 2 and guz >= 2:
		lastmove = "There is no The Guz to get."
		
	elif usrcmd.lower() == ("look trees") and roomx == 1 and roomy == 2:
		lastmove = "Blasted and gnarled, they struggle and fail to photosynthesize in the unending twilight of the antarctic night."
		
	elif usrcmd.lower() == ("get trees") and roomx == 1 and roomy == 2:
		lastmove = "The dead trees are of no use to you."
		
	elif usrcmd.lower() == ("talk trees") and roomx == 1 and roomy == 2:
		lastmove = "What are you hoping to learn, ancient tree wisdom?"
		
	elif usrcmd.lower() == ("look gundy's carpet") and roomx == 1 and roomy == 2 or usrcmd.lower() == ("look gundys carpet") and roomx == 1 and roomy ==2 or usrcmd.lower() == ("look moss") and roomx == 1 and roomy ==2:
		lastmove = "An olive-drab moss with a notable odor.  Some say if you hold it to your ear you can detect an audible whine."
		
	elif usrcmd.lower() == ("get gundy's carpet") and roomx == 1 and roomy == 2 and gcmoss == 0 or usrcmd.lower() == ("get gundys carpet") and roomx == 1 and roomy ==2 and gcmoss == 0 or usrcmd.lower() == ("get moss") and roomx == 1 and roomy ==2 and gcmoss == 0:
		lastmove = "You slice off a patch of the moss.  You note the distinctive odor, but can not decern any whine.  GUNDY'S CARPET is added to your INVENTORY."
		gcmoss = 1
		moss = moss + 1

	elif usrcmd.lower() == ("get gundy's carpet") and roomx == 1 and roomy == 2 and gcmoss == 1 or usrcmd.lower() == ("get gundys carpet") and roomx == 1 and roomy ==2 and gcmoss == 1 or usrcmd.lower() == ("get moss") and roomx == 1 and roomy ==2 and gcmoss == 1:
		lastmove = "You already have a sample of GUNDY'S CARPET in your INVENTORY.  Don't be greedy."

#		
#		
#Room x2, y2:  Goatman greg's
	elif usrcmd.lower() == ("look") and roomx == 2 and roomy == 2 and lookcreature == 0:
		lastmove = "You enter GOATMAN GREG's pub.  The room is close and dimly lit by several seal oil LAMPS, a banner of faded plastic shamrocks hangs above the bar.  Your feet stick to the floor.  NIGEL the Pedantic argues self righteously with DEATH at one of the tables."
		lastimage = "images/mossquest.gif"
		
	elif usrcmd.lower() == ("look") and roomx == 2 and roomy == 2 and lookcreature == 1:
		lastmove = "You enter GOATMAN GREG's pub.  The room is close and dimly lit by several seal oil LAMPS, a banner of faded plastic shamrocks hangs above the bar.  Your feet stick to the floor.  NIGEL the Pedantic argues self righteously with DEATH at one of the tables.  A Lovecraftian blackness seeps from cracks in the floor."
		lastimage = "images/mossquest.gif"
		
	elif usrcmd.lower() == ("look goatman greg") and roomx == 2 and roomy ==2:
		lastmove = "The barkeep is the eponymous GOATMAN GREG.  Outside man, inside goat, but goat doesn't fit very well into a man's skin, so the overall affect is unsettling."
	
	elif usrcmd.lower() == ("talk goatman greg") and roomx == 2 and roomy ==2:
		lastmove = "He gushes unintelligibly."
		
	elif usrcmd.lower() == ("look nigel") and roomx == 2 and roomy ==2 and deathquest == 0:
		lastmove = "A squat unattractive man with shrill voice and a unlovely pointed visage with skin the texture and moisture of mortadella."
	
	elif usrcmd.lower() == ("talk nigel") and roomx == 2 and roomy ==2 and deathquest == 0:
		lastmove = """Gesturing at DEATH; NIGEL whines, "This guy here doesn't know the difference between tartan and plaid!"  He prattles on for several minutes before asking for affirmation?  You aren't really sure what his argument is. [You can use command SIDE WITH DEATH or SIDE WITH NIGEL, or just ignore them]"""

	elif usrcmd.lower() == ("look nigel") and roomx == 2 and roomy ==2 and deathquest == 1:
		lastmove = "A squat unattractive man with shrill voice and a unlovely pointed visage with skin the texture and moisture of mortadella.  He huffs and pouts pissily, arms crossed."
	
	elif usrcmd.lower() == ("talk nigel") and roomx == 2 and roomy ==2 and deathquest == 1:
		lastmove = """ "I can't beleive you guys," Whinges NIGEL, gesticulating with pale, boney hands.  He continues talking but you tune him out quickly."""
				
	elif usrcmd.lower() == ("look death") and roomx == 2 and roomy ==2 and deathquest == 0:
		lastmove = "Collosal and gaunt, he is hunched in the low room, shrouded in black robes.  His long, dry fingers stiffly stretch and tighten around the hickory shaft of his scythe."
	
	elif usrcmd.lower() == ("talk death") and roomx == 2 and roomy ==2 and deathquest == 0:
		lastmove = "You aren't really sure what this argument is about, and you don't especially care.  Something about gingham?  Death looks in your direction and you can tell he's rolling his eyes beneath the hood. [You can use command SIDE WITH DEATH or SIDE WITH NIGEL, or just ignore them]"

	elif usrcmd.lower() == ("look death") and roomx == 2 and roomy ==2 and deathquest == 1:
		lastmove = "Collosal and gaunt, he is hunched in the low room, shrouded in black robes.  His long, dry fingers stiffly stretch and tighten around the frosty handle of his mug of cold one."
	
	elif usrcmd.lower() == ("talk death") and roomx == 2 and roomy ==2 and deathquest == 1:
		lastmove = "Death raises his cold one in your direction, geneily."

	elif usrcmd.lower() == ("side with death") and roomx == 2 and roomy ==2 and deathquest == 0:
		lastmove = "DEATH waves his sythe warmly in the direction of GOATMAN GREG, who comes by and pours you a COLD ONE.  COLD ONE added to your INVENTORY."
		coldone = 1
		deathquest = 1
		
	elif usrcmd.lower() == ("side with nigel") and roomx == 2 and roomy ==2 and deathquest == 0:
		easygui.msgbox("DEATH rises from his seat, bending in the low room.  The oil lamps dim as he directs his scythe at you.   You wonder why you ever would have sided with NIGEL.  Game over.")
		play = 0
	
	elif usrcmd.lower() == ("look cold one") and roomx == 2 and roomy ==2 and deathquest == 1:
		lastmove = "It's of a wholesome amber color, in a tall frosted glass mug."
		
	elif usrcmd.lower() == ("look lamps") and roomx == 2 and roomy ==2:
		lastmove = "They sputter in a claming way, and have coated the low wooden rafters in a greasy black film."

	elif usrcmd.lower() == ("get lamps") and roomx == 2 and roomy ==2:
		lastmove = "You reach to remove a lamp, but GOATMAN GREG gurgles threateningly."
	
		
	elif usrcmd.lower() == ("map") and roomx == 2 and roomy == 2 and map == 1 or usrcmd.lower() == ("map") and roomx == 2 and roomy == 2 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x2y2.gif"



#		
#		
#Room x2, y2:  Dumpster
	elif usrcmd.lower() == ("look") and roomx == 3 and roomy ==2:
		lastmove = "Passing through the narrow HERO'S TUNNEL next to Goatman Greg's you come upon the pub's DUMPSTER."
		lastimage = "images/herostunnel.gif"
		
	elif usrcmd.lower() == ("look hero's tunnel") and roomx == 3 and roomy ==2 or usrcmd.lower() == ("look heros tunnel") and roomx == 3 and roomy ==2:
		lastmove = """Through the low arch, you see the Pub. Besdie the tunnel sits a dingy sign that reads "Hero's Tunnel." """
		#lastmove = """Through the crawlspace just large enough to accommodate a man on hands and knees, you see the Pub. Above the tunnel sits a dingy sign that reads "Hero's Tunnel." """


	elif usrcmd.lower() == ("look dumpster") and roomx == 3 and roomy ==2 and snowshoes == 0:
		lastmove = """The dumpster reads "El DUMPO" on the side in faded block latters.  You see a pair of SNOWSHOES within the dumpster, a moaning and whining eminates from within."""
				
		
	elif usrcmd.lower() == ("look dumpster") and roomx == 3 and roomy ==2 and snowshoes == 1:
		lastmove = """The dumpster reads "El DUMPO" on the side in faded block latters."""
		
	elif usrcmd.lower() == ("get dumpster") and roomx == 3 and roomy ==2:
		lastmove = "Yeah, sure OK, whatever, DUMPSTER added to your INVENTORY. Happy?"
	
		
	elif usrcmd.lower() == ("look man") and roomx == 3 and roomy ==2 and snowshoes == 0:
		lastmove = "He howls and wildly scraches an armpit with thick yellow nails.  Dense mats of hair bristle from his underarm.  You'd rather not speak of the stench."
		
	elif usrcmd.lower() == ("look man") and roomx == 3 and roomy ==2 and snowshoes != 0:
		lastmove = "He howls and wildly scraches an armpit with thick yellow nails.  Dense mats of hair bristle from his underarm.  You'd rather not speak of the stench.  A bit of chum is stuck between his tombstone teeth."

	elif usrcmd.lower() == ("talk man") and roomx == 3 and roomy ==2 and snowshoes == 0:
		lastmove = """ "Man, I am dying for some sushi!" Says the MAN. "You wouldn't happen to have a fistful of raw fish, would you?  I'd gladly trade these here SNOWSHOES for a bit o' sushi." """

	elif usrcmd.lower() == ("talk man") and roomx == 3 and roomy ==2 and snowshoes == 1:
		lastmove = """He pats his stomach contentedly and let’s out a fishy belch. “That was some mighty fine sushi!” he intones."""


	elif usrcmd.lower() == ("give chum") and roomx == 3 and roomy ==2 and snowshoes == 0 and chum == 1 or usrcmd.lower() == ("give sushi") and roomx == 3 and roomy ==2 and snowshoes == 0 and chum == 1:
		lastmove = """ "Oh that'll do just fine!" says the man, reaching into your pocket and helping himself to great fistfuls of CHUM. You watch grimly as he brings handful after handful of fetid fish guts to his mouth, teeth gnashing and macerating the stinky pulp. He gulps down the last of the foul melange and wipes his hands on his potato sack before handing you the SNOWSHOES.  SNOWSHOES added to INVENTORY."""
		chum = 2
		snowshoes = 1

	elif usrcmd.lower() == ("give chum") and roomx == 3 and roomy ==2 and snowshoes == 0 and chum == 0 or usrcmd.lower() == ("give sushi") and roomx == 3 and roomy ==2 and snowshoes == 0 and chum == 0:
		lastmove = "You don't have anything to give."
		
	elif usrcmd.lower() == ("give chum") and roomx == 3 and roomy ==2 and snowshoes == 1 or usrcmd.lower() == ("give sushi") and roomx == 3 and roomy ==2 and snowshoes == 1:
		lastmove = "You don't have anything to give."

	elif usrcmd.lower() == ("get snowshoes") and roomx == 3 and roomy ==2 and snowshoes == 0:
		lastmove = "As you reach for the SNOWSHOES; a small, wet and bedragled MAN dressed in a burlap potato sack lunges at you, taking them from your hands."

	elif usrcmd.lower() == ("get snowshoes") and roomx == 3 and roomy ==2 and snowshoes == 1:
		lastmove = "You already have a pair of SNOWSHOES in your INVENTORY."
		
	elif usrcmd.lower() == ("look snowshoes") and roomx == 3 and roomy ==2 and snowshoes == 0:
		lastmove = "They look to be in good condition."

	elif usrcmd.lower() == ("look snowshoes") and roomx == 3 and roomy ==2 and snowshoes == 1:
		lastmove = "You already grabbed the snowshoes."
		
	elif usrcmd.lower() == ("map") and roomx == 3 and roomy == 2 and map == 1 or usrcmd.lower() == ("look map") and roomx == 3 and roomy == 2 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x3y2.gif"

		
		
#		
#		
#Room x4, y2 Bro House
	elif usrcmd.lower() == ("look") and roomx == 4 and roomy ==2 and gsmoss == 0 and smokes == 0:
		lastmove = "You come upon a dingy concrete hovel.  The interior is lit by a single overhead incandescent bulb, which bathes the room in cold, antiseptic light. Two youths sit on a cracked vinyl couch, serenaded by the soft rock of the Mission: Impossible Three DVD menu, which is playing on loop on a widescreen television. BRET vapes idly, looking forlornly at a pack of SMOKES on the gritty, ash covered coffee table. BRADEN is unresponsive."
		lastimage = "images/brohouse.gif"
		
	elif usrcmd.lower() == ("look") and roomx == 4 and roomy ==2 and gsmoss == 0 and smokes != 0:
		lastmove = "You come upon a dingy concrete hovel.  The interior is lit by a single overhead incandescent bulb, which bathes the room in cold, antiseptic light. Two youths sit on a cracked vinyl couch, serenaded by the soft muzak of the Mission: Impossible Three DVD menu, which is playing on loop on a widescreen television. BRET roots hoglike for his bag of hot takis. BRADEN is unresponsive.  Outside you see the antarctic sea under a leaden sky."
		lastimage = "images/brohouse.gif"
		
	elif usrcmd.lower() == ("look") and roomx == 4 and roomy ==2 and gsmoss == 1 and smokes == 0:
		lastmove = "You come upon a dingy concrete hovel.  The interior is lit by a single overhead incandescent bulb, which bathes the room in cold, antiseptic light. Two youths sit on a cracked vinyl couch, serenaded by the soft muzak of the Mission: Impossible Three DVD menu, which is playing on loop on a widescreen television. BRET vapes idly, looking forlornly at a pack of SMOKES on the gritty, ash covered coffee table. BRADEN is responsive."
		lastimage = "images/brohouse.gif"
		
	elif usrcmd.lower() == ("look") and roomx == 4 and roomy ==2 and gsmoss == 1 and smokes != 0:
		lastmove = "You come upon a dingy concrete hovel.  The interior is lit by a single overhead incandescent bulb, which bathes the room in cold, antiseptic light. Two youths sit on a cracked vinyl couch, serenaded by the soft muzak of the Mission: Impossible Three DVD menu, which is playing on loop on a widescreen television. BRET roots hoglike for his bag of penguin jerkey. BRADEN is responsive.  Outside you see the antarctic sea under a leaden sky."
		lastimage = "images/brohouse.gif"
		
	elif usrcmd.lower() == ("map") and roomx == 4 and roomy == 2 and map == 1 or usrcmd.lower() == ("look map") and roomx == 4 and roomy == 2 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x4y2.gif"

		
	elif usrcmd.lower() == ("look smokes") and roomx == 4 and roomy ==2 and smokes == 0:
		lastmove = "Unfiltered. It figures."

	elif usrcmd.lower() == ("look smokes") and roomx == 4 and roomy ==2 and smokes == 1:
		lastmove = "The smokes are now in your pocket."
		
	elif usrcmd.lower() == ("look smokes") and roomx == 4 and roomy ==2 and smokes == 2:
		lastmove = "There aren't any smokes around."
		
	elif usrcmd.lower() == ("get smokes") and roomx == 4 and roomy ==2 and smokes == 0:
		lastmove = "You add a pack of SMOKES to your inventory.  The bros don't seem to notice."
		smokes = 1

	elif usrcmd.lower() == ("get smokes") and roomx == 4 and roomy ==2 and smokes != 0:
		lastmove = "You already pinched their smokes."

	elif usrcmd.lower() == ("look bret") and roomx == 4 and roomy ==2:
		lastmove = "He has paired his stained grey sweatpants with a yellowing wifebeater, completing the look with an oversized parka and flat brimmed hat, pearched at a jaunty angle. Plumes of sickeningly sweet vapor issue perriodically from his nose and mouth."

	elif usrcmd.lower() == ("talk bret") and roomx == 4 and roomy ==2 and gsmoss == 0:
		lastmove = """BRET sighs, a purple cloud pouring from his chapped lips. “BRADEN’s been in a K-hole for like, two hours, and only he knows where the remote is,” he complains. “Too bad we just ran outta of snail water. That gets him out of it every time!” """

	elif usrcmd.lower() == ("talk bret") and roomx == 4 and roomy ==2 and gsmoss == 1:
		lastmove = """ “I just wanna fuckin watch something else” BRET complains bitterly, as the Mission: Impossible 3 DVD menu continues its ambient loop." """

	elif usrcmd.lower() == ("look braden") and roomx == 4 and roomy ==2 and gsmoss == 0:
		lastmove = "BRADEN slouches in his camo cargo shorts, head resting on the back of the couch. Drool leaks from the corner of his open mouth and drips southward onto his pasty paunch. He isn’t wearing a shirt."
	
	elif usrcmd.lower() == ("talk braden") and roomx == 4 and roomy ==2 and gsmoss == 0:
		lastmove = "I think you know that isn't happening.  BRADEN gurgles faintly."
		
	elif usrcmd.lower() == ("look braden") and roomx == 4 and roomy ==2 and gsmoss == 1:
		lastmove = "BRADEN jealously guards the remote from BRET. He rolls and rerolls a joint on the waist high pile of pizza boxes next to the couch."
	
	elif usrcmd.lower() == ("talk braden") and roomx == 4 and roomy ==2 and gsmoss == 1:
		lastmove = "You don’t want to get roped into getting talked at about his mixtape, do you?"
		
	elif usrcmd.lower() == ("give snails") and roomx == 4 and roomy ==2 and snails == 1 and gsmoss == 0:
		lastmove = """ "Oh tight dude!" BRET rasps, dropping the snails into an empty bottle of Mountain Dew, topping it off with bongwater. He recaps the bottle and shakes it into a foul, frothy brew. BRADEN slowly comes to as BRET dribbles the mucosal foam into his agape maw, and presently produces the sweaty remote from under a seat cushion. BRADEN hands you a damp pizza box, wherein you find a rich sample of GIUSEPPE’S SHAG.  GIUSEPPE’S SHAG is added to your INVENTORY."""
		gsmoss = 1
		snails = 0
		moss = moss + 1
		
	elif usrcmd.lower() == ("give snails") and roomx == 4 and roomy ==2 and snails == 0 and gsmoss == 0:
		lastmove = "You don't have any snails handy."

	elif usrcmd.lower() == ("give snails") and roomx == 4 and roomy ==2 and snails == 0 and gsmoss == 1:
		lastmove = "They already cleaned you out of all the snails you had."		

	elif usrcmd.lower() == ("give snails") and roomx == 4 and roomy ==2 and snails == 1 and gsmoss == 1:
		lastmove = """ "Nah bro, we've got plenty." """

	elif usrcmd.lower() == ("look dvd") and roomx == 4 and roomy ==2:
		lastmove = "It's concealed inside the DVD player"
		
	elif usrcmd.lower() == ("get dvd") and roomx == 4 and roomy ==2:
		lastmove = "You reach to eject the DVD but BRET throws an empty can of mountian dew at you.  You desist."

	elif usrcmd.lower() == ("get bret") and roomx == 4 and roomy ==2:
		lastmove = "You don't want BRET."
	
	elif usrcmd.lower() == ("get braden") and roomx == 4 and roomy ==2:
		lastmove = "You don't want BRADEN."

########## y3 ##########	
#		
#Room x1, y3 DIAPER PETE's place
	elif usrcmd.lower() == ("look") and roomx == 1 and roomy ==3:
		lastmove = "DIAPER PETE glares suspiciously at you through the slats in his PALISADE.  He taps a stick against the stakes threateningly.  You can see a lush plot of PEAT inside the PALISADE."
		lastimage = "images/diaperpete.gif"
		
	elif usrcmd.lower() == ("map") and roomx == 1 and roomy == 3 and map == 1 or usrcmd.lower() == ("look map") and roomx == 1 and roomy == 3 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x1y3.gif"
		
	elif usrcmd.lower() == ("look diaper") and roomx == 1 and roomy ==3:
		lastmove = "Nope, you've seen enough."

	elif usrcmd.lower() == ("get diaper") and roomx == 1 and roomy ==3:
		lastmove = "Sicko, absolutely not."

	elif usrcmd.lower() == ("look palisade") and roomx == 1 and roomy ==3:
		lastmove = "A fortress made of crudely sharpened sticks, it looks to be constructed just to protect DIAPER PETE's DIAPER PEAT."
		
	elif usrcmd.lower() == ("look diaper pete") and roomx == 1 and roomy ==3 and diaperquest == 0:
		lastmove = "A skinny, sickly looking man, his head twitches as he eyes you, slackjawed, and his bony knees knock together.  His knuckles are white on the blunt stick.  He seems to be wearing only his eponymous diaper, lumpy clumps of moss bulge out of the patched, threadbear cloth.  You get a sense the he could do with a diaper upgrade."

	elif usrcmd.lower() == ("look diaper pete") and roomx == 1 and roomy ==3 and diaperquest == 1:
		lastmove = "DIAPER PETE peers out of the palisade. A slow, wet sound comes from his new diaper. You understand now why he used to be known as Leaky Pete."

	elif usrcmd.lower() == ("talk diaper pete") and roomx == 1 and roomy ==3 and diaperquest == 0:
		lastmove = "His bloodshot eyes twitch, he brandishes his stick at you.  A slow, wet noise comes from the diaper.  You become aware of the pungent scent of doo."
		
	elif usrcmd.lower() == ("talk diaper pete") and roomx == 1 and roomy ==3 and diaperquest == 1:
		lastmove = "You decide to definately not talk to DIAPER PETE."

	elif usrcmd.lower() == ("look diaper peat") and roomx == 1 and roomy ==3 or usrcmd.lower() == ("look peat") and roomx == 1 and roomy ==3:
		lastmove = "DIAPER PETE seems very protective of his DIAPER PEAT"
		
	elif usrcmd.lower() == ("get diaper peat") and roomx == 1 and roomy ==3 and diaperquest == 0 or usrcmd.lower() == ("get peat") and roomx == 1 and roomy ==3 and diaperquest == 0:
		lastmove = "DIAPER PETE is not going to let you have any of his DIAPER PEAT"
		
	elif usrcmd.lower() == ("get diaper peat") and roomx == 1 and roomy ==3 and diaperquest == 1 or usrcmd.lower() == ("get peat") and roomx == 1 and roomy ==3 and diaperquest == 1:
		lastmove = "DIAPER PETE is not going to let you have any more of his DIAPER PEAT"

	elif usrcmd.lower() == ("give diaper") and roomx == 1 and roomy ==3 and diaper != 1:
		lastmove = "You have no diaper to give"	

	elif usrcmd.lower() == ("give diaper") and roomx == 1 and roomy ==3 and diaper == 1:
		lastmove = "Using a long pole you’ve found on the ground, you gently pass the DIAPER through the palisade wall. DIAPER PETE snatches the shearling garment from the end of the pole, stuffs it with peat moss and promptly drops trow.  He flings his old, befouled cloth over the palisade wall, nearly missing you.  You take a few steps closer to the compound, avoiding the poopy sack, and are frantically showered in several dark clumps of peat. You add DIAPER PEAT to your INVENTORY."
		diaper = 0
		dpmoss = 1
		diaperquest = 1
		moss = moss + 1

	elif usrcmd.lower() == ("give smokes") and roomx == 1 and roomy ==3 and smokes == 1:
		lastmove = "DIAPER PETE doesn't smoke, and is frankly offended by your offer."	

		
#		
#		
#Room x2, y3	west pasture
	elif usrcmd.lower() == ("look") and roomx == 2 and roomy == 3 and loudandy <= 1 and lookcreature == 0: #loud andy, no vile creature
		lastmove = "Several stocky SHEEP masticate nervously.  They totter urgently away at the sound of your footsteps.  In the distance you spy a heavy-set SHEPHERD gesticulating beesechingly with his crook."
		lastimage = "images/westpasture.gif"
		
	elif usrcmd.lower() == ("look") and roomx == 2 and roomy == 3 and loudandy == 2 and lookcreature == 0: #no loud andy, no vile creature
		lastmove = "In the distance you spy a heavy-set SHEPHERD.  Only a few sheep remain in this pasture."
		lastimage = "images/westpasture.gif"
		
	elif usrcmd.lower() == ("look") and roomx == 2 and roomy == 3 and loudandy <= 1 and lookcreature == 1: #loud andy, vile creature
		lastmove = "Several stocky SHEEP masticate nervously.  They totter urgently away at the sound of your footsteps.  In the distance you spy a heavy-set SHEPHERD gesticulating beesechingly with his crook.  You sense the vile black creatures lurking unseen."
		lastimage = "images/westpasture.gif"
		
	elif usrcmd.lower() == ("look") and roomx == 2 and roomy == 3 and loudandy == 2 and lookcreature == 1: #no loud andy, vile creature
		lastmove = "In the distance you spy a heavy-set SHEPHERD.  Only a few sheep remain in this pasture.  You sense the vile black creatures lurking unseen."
		lastimage = "images/westpasture.gif"
		
	elif usrcmd.lower() == ("map") and roomx == 2 and roomy == 3 and map == 1 or usrcmd.lower() == ("look map") and roomx == 2 and roomy == 3 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x2y3.gif"
		
	elif usrcmd.lower() == ("look sheep") and roomx == 2 and roomy == 3 and loudandy <= 1:
		lastmove = "Their vacuous and uninteligent eyes dart left and right.  They seem spooked."
		
	elif usrcmd.lower() == ("look sheep") and roomx == 2 and roomy == 3 and loudandy == 2:
		lastmove = "They don't seem spooked."
		
	elif usrcmd.lower() == ("talk sheep") and roomx == 2 and roomy == 3:
		lastmove = "They stare at you stupidly."
		
	elif usrcmd.lower() == ("look shepherd") and roomx == 2 and roomy == 3 and loudandy <= 1:
		lastmove = "A aged, beefy man with as many folds as he has sheep.  His loose neck skin seem to drip off his ruddy chin.  He beckons for you to speak with him."
		lastimage = "images/shepherd.gif"
		
	elif usrcmd.lower() == ("look shepherd") and roomx == 2 and roomy == 3 and loudandy == 2:
		lastmove = "A aged, beefy man with as many folds as he has sheep.  His loose neck skin seem to drip off his ruddy chin."
		lastimage = "images/shepherd.gif"
		
	elif usrcmd.lower() == ("talk shepherd") and roomx == 2 and roomy == 3 and loudandy <= 1:
		lastmove = """The heavy man shifts his imploring gaze from his wayward flock. “Were it not for the foul demon Loud Andy we’d be making tracks for greener pastures east, but he’s spooked the poop out of m'sheep!  If only my lumbego didn't prevent me from visiting some kind of powerful wizard or warlock,” he bemoans. """
		lastimage = "images/shepherd.gif"

	elif usrcmd.lower() == ("talk shepherd") and roomx == 2 and roomy == 3 and loudandy == 2 and diaper == 0:
		lastmove = """ “Many thanks for dealing with that demon’s infernal yodeling” says the SHEPHERD, neck skins fluttering. “I’m sure my sheep have missed the eastern pasture.” He reaches into his robe and gives you what appears to be a folded sheepskin. “It’s not much, but I’d like you to have this shearling diaper as a token of my appreciation. And help yourself to as much moss as you’d like.” """
		lastimage = "images/shepherd.gif"
		diaper = 1
		
	elif usrcmd.lower() == ("talk shepherd") and roomx == 2 and roomy == 3 and loudandy == 2 and diaper == 1:
		lastmove = """ “Many thanks for dealing with that demon’s infernal yodeling” says the SHEPHERD, neck skins fluttering. “Help yourself to as much moss as you’d like from the east pasture.” """
		lastimage = "images/shepherd.gif"
		
	elif usrcmd.lower() == ("look moss") and roomx == 2 and roomy == 3:
		lastmove = "The moss here is a bit overgrazed.  The moss in the eastern pasture looks much more fruitful."
		
	elif usrcmd.lower() == ("get moss") and roomx == 2 and roomy == 3:
		lastmove = "There isn't much moss to get.  The moss in the eastern pasture looks much more fruitful."
		
	elif usrcmd.lower() == ("get sheep") and roomx == 2 and roomy == 3:
		lastmove = "You don't want to get accused of rustling."
		
	elif usrcmd.lower() == ("give incantation") and roomx == 2 and roomy == 3 and loudandy == 1:
		lastmove = "The shepherd shakes his head and directs you to give the INCANTATION in the presence of Loud Andy, to the east."
		lastimage = "images/shepherd.gif"

	elif usrcmd.lower() == ("give smokes") and roomx == 2 and roomy == 3 and smokes == 1:
		lastmove = "The shepherd shakes his head and wordlessly takes his own pack from his pocket in answer."

#		
#		
#Room x3, y3: east pasture	
	elif usrcmd.lower() == ("look") and roomx == 3 and roomy == 3 and loudandy <= 1:
		lastmove = "You come upon a lush pasture carpeted in ungrazed MOSS. The foul demon LOUD ANDY floats above blowing powerful, lusty raspberries."
		lastimage = "images/eastpasture1.gif"
		
	elif usrcmd.lower() == ("map") and roomx == 3 and roomy == 3 and map == 1 or usrcmd.lower() == ("look map") and roomx == 3 and roomy == 3 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x3y3.gif"
		
	elif usrcmd.lower() == ("look") and roomx == 3 and roomy == 3 and loudandy == 2:
		lastmove = "Several sheep graze upon the lush carpets of MOSS."
		lastimage = "images/eastpasture3.gif"
		
	elif usrcmd.lower() == ("look moss") and roomx == 3 and roomy == 3 or usrcmd.lower() == ("look brundled sphagnum") and roomx == 3 and roomy == 3:
		lastmove = "It appears to be a specemin of BRUNDLED SPHAGNUM, known for its prominent brundulations."
	
	elif usrcmd.lower() == ("get moss") and roomx == 3 and roomy == 3 and loudandy <= 1 or usrcmd.lower() == ("get brundled sphagnum") and roomx == 3 and roomy == 3 and loudandy <= 1:
		lastmove = "LOUD ANDY flutters his bat wings, ululates, and hawks a considerable loogie in your direction. You decide to leave the MOSS alone for now."
		
	elif usrcmd.lower() == ("get moss") and roomx == 3 and roomy == 3 and loudandy == 2 and bsmoss != 1 or usrcmd.lower() == ("get brundled sphagnum") and roomx == 3 and roomy == 3 and loudandy == 2 and bsmoss != 1 :
		lastmove = "BRUNDLED SPHAGNUM is added to your INVENTORY"
		bsmoss = 1
		moss = moss + 1
		
	elif usrcmd.lower() == ("get moss") and roomx == 3 and roomy == 3 and loudandy == 2 and bsmoss == 1 or usrcmd.lower() == ("get brundled sphagnum") and roomx == 3 and roomy == 3 and loudandy == 2 and bsmoss == 1 :
		lastmove = "You already have a sample of BRUNDLED SPHAGNUM in your INVENTORY"
	
	elif usrcmd.lower() == ("get loud andy") and roomx == 3 and roomy == 3 and loudandy <= 1:
		lastmove = "Even if you could get LOUD ANDY, why would you want to?"
		
	elif usrcmd.lower() == ("look loud andy") and roomx == 3 and roomy == 3 and loudandy <= 1:
		lastmove = "LOUD ANDY circles above on the leathery wings of a bat. He swings his bifurcated tail suggestively and makes a rude hand gesture with his numerous, unseemly hands. He has begun yodeling, it is incredibly offensive."
		
	elif usrcmd.lower() == ("talk loud andy") and roomx == 3 and roomy == 3 and tla == 1 and loudandy <= 1:
		lastmove = """ “Hey stupid, blow it out your ear!” Warbles LOUD ANDY gratingly. """
		tla = 2
		
	elif usrcmd.lower() == ("talk loud andy") and roomx == 3 and roomy == 3 and tla == 2 and loudandy <= 1:
		lastmove = """ "I’ll shit down your throat, you stupid bitch," he shouts at you, clearly getting worked up."""
		tla = 1
		
	elif usrcmd.lower() == ("look loud andy") and roomx == 3 and roomy == 3 and loudandy == 2:
		lastmove = "Loud Andy has been banished to some other region."
				
	elif usrcmd.lower() == ("talk loud andy") and roomx == 3 and roomy == 3 and loudandy == 2:
		lastmove = "Loud Andy has been banished to some other dimention."
		
	elif usrcmd.lower() == ("give smokes") and roomx == 3 and roomy == 3 and loudandy <= 1 and smokes == 1:
		lastmove = "Loud Andy doesn't smoke and is offended by your offer."
		
	elif usrcmd.lower() == ("give incantation") and roomx == 3 and roomy == 3 and loudandy == 1:
		lastmove = """Shaking your fist skyward, you shout, “you’ll never get away with this LOUD ANDY!”  An unspeakable portal to the nether is conjured in the sky above the foul demon.  LOUD ANDY simpers and whines into the vortex, to be seen no more. Out of the corner of your eye you see several sheep begin to amble vacantly towards the green pasture."""
		loudandy = 2
		lastimage = "images/eastpasture2.gif"
		
	elif usrcmd.lower() == ("get sheep") and roomx == 3 and roomy == 3 and loudandy == 2:
		lastmove = "You don't want to get accused of rustling."
		
	elif usrcmd.lower() == ("look sheep") and roomx == 3 and roomy == 3 and loudandy == 2:
		lastmove = "They stare at you stupidly."
		
	



#		
#		
#Room x4, y3	Penguin colony 
	elif usrcmd.lower() == ("look") and roomx == 4 and roomy ==3:
		lastmove = "You are assailed by a loathsome avian fetor that slowly penetrates to your very marrow.  Hundreds of PENGUINS encircle you, their unblinking black eyes trained on you. They scream cacophonously."
		lastimage = "images/penguins.gif"
		
	elif usrcmd.lower() == ("map") and roomx == 4 and roomy == 3 and map == 1 or usrcmd.lower() == ("look map") and roomx == 4 and roomy == 3 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x4y3.gif"
		
	elif usrcmd.lower() == ("look penguins") and roomx == 4 and roomy ==3 or usrcmd.lower() == ("look penguin") and roomx == 4 and roomy ==3:
		lastmove = "Some waddle comically, their feet slapping the wet sand absurdly.  Others sit on clutches of EGGS."
		
	elif usrcmd.lower() == ("get penguins") and roomx == 4 and roomy ==3 and penguinquest == 0 or usrcmd.lower() == ("get penguin") and roomx == 4 and roomy ==3 and penguinquest == 0:
		lastmove = "You pick one up but it feels to be made of lead, and pecks and kicks ferociously.  You drop it hastily, but the smell sticks to you."
		
	elif usrcmd.lower() == ("get penguins") and roomx == 4 and roomy ==3 and penguinquest == 1 or usrcmd.lower() == ("get penguin") and roomx == 4 and roomy ==3 and penguinquest == 1:
		lastmove = "You toss the sealer's sullied sack over the head of the nearest bird.  It screams plaintively, but you are reasonably protected from its struggling.  PENGUIN added to your INVENTORY."
		penguinquest = 2
		
	elif usrcmd.lower() == ("get penguins") and roomx == 4 and roomy ==3 and penguinquest == 2 or usrcmd.lower() == ("get penguin") and roomx == 4 and roomy ==3 and penguinquest == 2:
		lastmove = "You've already got one of the PENGUINS in your INVENTORY.  You can't carry two, those things are heavy."
		
	elif usrcmd.lower() == ("get penguins") and roomx == 4 and roomy ==3 and penguinquest == 3 or usrcmd.lower() == ("get penguin") and roomx == 4 and roomy ==3 and penguinquest == 3:
		lastmove = "Nope."
		
	elif usrcmd.lower() == ("look eggs") and roomx == 4 and roomy ==3 or usrcmd.lower() == ("look egg") and roomx == 4 and roomy ==3:
		lastmove = "White ovate orbs."
		
	elif usrcmd.lower() == ("get eggs") and roomx == 4 and roomy ==3 and branch != 1 or usrcmd.lower() == ("get egg") and roomx == 4 and roomy ==3 and branch != 1:
		lastmove = "The parent will have no such thing."

	elif usrcmd.lower() == ("get eggs") and roomx == 4 and roomy ==3 and branch == 1 or usrcmd.lower() == ("get egg") and roomx == 4 and roomy ==3 and branch == 1:
		lastmove = "Using your blunt branch liberally, you manage to coax a parent off their prized clutch.  EGG is added to your INVENTORY"
		egg = 1

	elif usrcmd.lower() == ("give chum") and roomx == 4 and roomy ==3 and chum == 1:
		lastmove = "They look down their beaks at your paltry offering.  They have plenty of gross fish of their own."
		
	elif usrcmd.lower() == ("talk penguins") and roomx == 4 and roomy ==3 or usrcmd.lower() == ("talk penguin") and roomx == 4 and roomy ==3:
		lastmove = "Their keening and wailing only increases. How can you expect to make conversation with PENGUINS? You meet their black gazes but do not feel especially seen."
	
		
		
		
########## y4 ##########
#		
#Room x1, y4  Sealer		
	elif usrcmd.lower() == ("look") and roomx == 1 and roomy ==4 and penguinquest <= 2:
		lastmove = "Shrouded in a powerful, black smoke; a SEALER with a physique like a haystack stirs a foul bubbling TRY POT.  The vacinity is slick with a slurry of loathsome oils in various stages and qualities.  Bits of seals and penguins squelch beneath the SEALER's blocky, greasy boots.  He wipes his forehead with a slick carpet of MUDPUPPY'S DUVET."
		lastimage = "images/sealer.gif"
		
	elif usrcmd.lower() == ("map") and roomx == 1 and roomy == 4 and map == 1 or usrcmd.lower() == ("look map") and roomx == 1 and roomy == 4 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x1y4.gif"
		
	elif usrcmd.lower() == ("look") and roomx == 1 and roomy ==4 and penguinquest == 3:
		lastmove = "Shrouded in a powerful, black smoke; a SEALER with a physique like a haystack beats back a scalded penguin, trying to escape from a bubbling TRY POT.  The vacinity is slick with a slurry of loathsome oils in various stages and qualities.  Bits of seals and penguins squelch beneath the SEALER's blocky, greasy boots."
		lastimage = "images/sealer.gif"

	elif usrcmd.lower() == ("look sealer") and roomx == 1 and roomy ==4:
		lastmove = "You have never seen movement so accurately described as lumbering.  The SEALER lumbers with a great churning of his thick arms, so his steady locomotion seems to be accomplished with a considerable expenditure of energy.  It appears the grease is ubiquitous on his person.  He lives upon grease, his clothes are penetrated fully with it, he eats it, drinks it, and washes in vats of it; until it seems actually coming through his pores and it anoints his hair, which is slathered on his head like fibrous peanut butter, over which he wears a sou'wester.  The slight drizzle splashes off his haystackesque form like from a duck's back."

	elif usrcmd.lower() == ("talk sealer") and roomx == 1 and roomy ==4 and penguinquest == 0:
		lastmove = """He has a heavy Newfoundland accent, "ile is the main source of energy in Mossfell during the winter.  Keeps the lights on m' b'y." Even his voice is oily. "Would you mind fetching me another penguin, don' want to leave the TRY POT, and she still got room for another birdo."  He hands you a profoundly grease soaked canvas sack, presumebally with which to catch the penguin."""
		penguinquest = 1
		
	elif usrcmd.lower() == ("talk sealer") and roomx == 1 and roomy ==4 and penguinquest == 1:
		lastmove = """ "Would you mind fetching me another penguin?  I don' want to leave the TRY POT, and she still got room for another ile birdo." """

	elif usrcmd.lower() == ("talk sealer") and roomx == 1 and roomy ==4 and penguinquest == 2:
		lastmove = "With a grunt you deposit the squirming sack by the TRY POT.  The SEALER deftly upturns it, and drops the live, screaming penguin into the boiling oil.  After a brief barter, you accept the stained MUDPUPPY'S DUVET as payment.  MUDPUPPY'S DUVET added to your INVENTORY."
		penguinquest = 3
		mpdmoss = 1
		moss = moss + 1
		
	elif usrcmd.lower() == ("give penguin") and roomx == 1 and roomy ==4 and penguinquest == 2:
		lastmove = "With a grunt you deposit the squirming sack by the TRY POT.  The SEALER deftly upturns it, and drops the live, screaming penguin into the boiling oil.  After a brief barter, you accept the stained MUDPUPPY'S DUVET as payment.  MUDPUPPY'S DUVET added to your INVENTORY."
		penguinquest = 3
		mpdmoss = 1
		moss = moss + 1

	elif usrcmd.lower() == ("talk sealer") and roomx == 1 and roomy ==4 and penguinquest == 3:
		lastmove = """ "Long may your big jib draw!" """

	elif usrcmd.lower() == ("look try pot") and roomx == 1 and roomy ==4:
		lastmove = "It is a large cast iron cauldron. A dense cloud of repulsive black smoke comes off the surface of lumpy, simmering fat."
		
	elif usrcmd.lower() == ("get try pot") and roomx == 1 and roomy ==4:
		lastmove = "It is both too hot and too heavy."
		
	elif usrcmd.lower() == ("look mudpuppy's duvet") and roomx == 1 and roomy ==4 and penguinquest <= 2:
		lastmove = "A moss reknowned for its soft texture and absorbent qualities, though this particular specemin is so oilstricken that its sporophytes are matted and moist."
		
	elif usrcmd.lower() == ("look mudpuppy's duvet") and roomx == 1 and roomy ==4 and penguinquest == 3:
		lastmove = "It is in your INVENTORY."
		
	elif usrcmd.lower() == ("get mudpuppy's duvet") and roomx == 1 and roomy ==4 and penguinquest <= 2:
		lastmove = "The SEALER is lothe to part with it.  He claims it is the best thing for sopping up oil."
		
	elif usrcmd.lower() == ("get mudpuppy's duvet") and roomx == 1 and roomy ==4 and penguinquest == 3:
		lastmove = "You already have MUDPUPPY'S DUVET in your INVENTORY."
		
		#You proffer Mrs. Tisdale’s grotesque mummy, and the sealer snatches the blackened senior from you with one of his great hands. He remarks upon the quality and liquid resistant nature of “the leather”, and hands you a fistful of mudpuppy’s duvet in return. You add mudpuppy’s duvet to your inventory.


#		
#		
#Room x2, y4	Gail Forcewinds
		
	elif usrcmd.lower() == ("look") and roomx == 2 and roomy ==4 and egg != 2:
		lastmove = "Among the rocks of the green splotched bog that extends to the russet slopes of Mt. Mossfell, you find an entryway to diminutive cave in front of which sits GAIL FORCEWINDS looking rather discontent. She reads from a MAGAZINE while tending a fire surrounded by cast iron pots and pans and a single BOX of cereal.  A basket filled with BUNGLED BROWN moss sits beside her."
		lastimage = "images/mossquest.gif"
	
	elif usrcmd.lower() == ("look") and roomx == 2 and roomy ==4 and egg == 2:
		lastmove = "Among the rocks of the green splotched bog that extends to the russet slopes of Mt. Mossfell, you find an entryway to diminutive cave in front of which sits GAIL FORCEWINDS looking rather content. She uses pages from her MAGAZINE to wipe mayonaise off her fingers, while tending a fire.  A basket filled with BUNGLED BROWN moss sits on her one side, a single BOX of cereal on her other."
		lastimage = "images/mossquest.gif"
		
	elif usrcmd.lower() == ("look gail forcewinds") and roomx == 2 and roomy ==4 and egg != 2 or usrcmd.lower() == ("look gail") and roomx == 2 and roomy ==4 and egg != 2:
		lastmove = "GAIL is a buxom, middle aged Jewish woman. You are surprised to see that she is meagerly dressed in sack cloth. While of an energetic constitution, Gail seems rather dejected."

	elif usrcmd.lower() == ("look gail forcewinds") and roomx == 2 and roomy ==4 and egg == 2 or usrcmd.lower() == ("look gail") and roomx == 2 and roomy ==4 and egg == 2:
		lastmove = "GAIL is a buxom, middle aged Jewish woman. You are surprised to see that she is meagerly dressed in sack cloth. While of an energetic constitution, Gail seems bouyant and carefree."


	elif usrcmd.lower() == ("talk gail forcewinds") and roomx == 2 and roomy ==4 and egg == 0 or usrcmd.lower() == ("talk gail") and roomx == 2 and roomy ==4 and egg == 0:
		lastmove = """ "Feh! I can't take another meal of this garbage! This diet is meshuggah!" Says GAIL spiritedly, gesturing towards the BOX of cereal with her MAGAZINE. "I thought that this downsizing less-is-more lifestyle would be good fah me but all I am is hangry! What I wouldn't do fah some egg salad! And my turds, you wouldn't even believe!" """
	
	elif usrcmd.lower() == ("talk gail forcewinds") and roomx == 2 and roomy ==4 and egg == 1 or usrcmd.lower() == ("talk gail") and roomx == 2 and roomy ==4 and egg == 1:
		lastmove = """ "Feh! I can't take another meal of this garbage! This diet is meshuggah!" Says GAIL spiritedly, gesturing towards the BOX of cereal with her MAGAZINE. "I thought that this downsizing less-is-more lifestyle would be good fah me but all I am is hangry! What I wouldn't do fah some egg salad! Have you got an egg?" """
	
	elif usrcmd.lower() == ("talk gail forcewinds") and roomx == 2 and roomy ==4 and egg == 2 or usrcmd.lower() == ("talk gail") and roomx == 2 and roomy ==4 and egg == 2:
		lastmove = """Gail sucks mayonnaise from beneath her long fingernails.  "Thank you, you're truly a mensch." """
	
	elif usrcmd.lower() == ("look magazine") and roomx == 2 and roomy ==4:
		lastmove = """Gail reads a copy of Deprivation Weekly, which depicts an assortment of youths who are suspiciously jaunty for people wearing potato sacks. The sack cloth clad youths romp through a field of headlines such as "From Penthouse to No House in Three Easy Steps!" """
		
	elif usrcmd.lower() == ("get magazine") and roomx == 2 and roomy ==4:
		lastmove = "It's the only thing she has.  Best leave her with something."
		
	elif usrcmd.lower() == ("look box") and roomx == 2 and roomy ==4:
		lastmove = "The BOX is labeled Honey Bunches of Moths: Oops, All Moths.  Which sounds about as palatable as the foul slime of the great morass.  You look upon GAIL; here was a mouth manifestly intended for greater things in the way of gastronomy than moths."

	elif usrcmd.lower() == ("get box") and roomx == 2 and roomy ==4:
		lastmove = "Your mother Gurtha fights so hard to keep moths out of the pantry at home.  You daren't imagine her reaction if you brought this in."

	elif usrcmd.lower() == ("look bungled brown") and roomx == 2 and roomy ==4 or usrcmd.lower() == ("look moss") and roomx == 2 and roomy ==4:
		lastmove = "It is richly bungled."
		
	elif usrcmd.lower() == ("get bungled brown") and roomx == 2 and roomy ==4 and egg <= 1 or usrcmd.lower() == ("get moss") and roomx == 2 and roomy ==4 and egg <= 1:
		lastmove = """GAIL FORCEWINDS raises a weak hand to stop you, "Oh sweetie" she says, "That's the only decoration I've permitted myself around here.  Allow me this one little indulgance." """

	elif usrcmd.lower() == ("get bungled brown") and roomx == 2 and roomy ==4 and egg == 2 or usrcmd.lower() == ("get moss") and roomx == 2 and roomy ==4 and egg == 2:
		lastmove = "GAIL FORCEWINDS is devouring her small egg salad voraciously with her hands, licking mayonaise off her forearms.  She grunts and nods atavistically when you ask for some moss.  BUNGLED BROWN moss added to your INVENTORY."
		moss = moss + 1
		bbmoss = 1

	
	elif usrcmd.lower() == ("give egg") and roomx == 2 and roomy ==4 and egg == 1:
		lastmove = "With great flurish, you produce an egg, GAIL FORCEWINDS jumps on it ravenously."
		egg = 2	
	

		
	elif usrcmd.lower() == ("map") and roomx == 2 and roomy == 4 and map == 1 or usrcmd.lower() == ("look map") and roomx == 2 and roomy == 4 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x2y4.gif"
		

			
		
#		
#		
#Room x3, y4 Vineyard
	elif usrcmd.lower() == ("look") and roomx == 3 and roomy ==4:
		lastmove = "In the sad drizzle beneath the dim moonshadow of Mt. Mossfell, JEAN TABARNAK kneels examining the weird bunches of morbid GROWTHS suspended from the unwholesome, grey VINES."
		lastimage = "images/mossquest.gif"
		
	elif usrcmd.lower() == ("look vines") and roomx == 3 and roomy ==4:
		lastmove = "They somewhat resemble the VINES pictured on the old bottles of wine your ma kept in the root cellar.  Only smaller, and more dying.  You notice a patch of POUPE ROT at the base of the vines."

	elif usrcmd.lower() == ("look poupe rot") and roomx == 3 and roomy ==4:
		lastmove = "The POUPE ROT is an old wolrd parasitic moss.  You've never seen it before.  It's brown."
		
	elif usrcmd.lower() == ("look growths") and roomx == 3 and roomy == 4 or usrcmd.lower() == ("look grapes") and roomx == 3 and roomy == 4 or usrcmd.lower() == ("look morbid growths") and roomx == 3 and roomy == 4:
		lastmove = "Splotchy, swollen orbs, giving off an offputting carnal fœtor.  There are not very many of them."
	
	elif usrcmd.lower() == ("look jean") and roomx == 3 and roomy == 4 or usrcmd.lower() == ("look jean tabarnak") and roomx == 3 and roomy == 4:
		lastmove = "He is an elderly man with short white hair, wearing a heavy blue and white striped shirt.  He kneels in the mud picking at the GROWTHS with his opaque and unsettlingly thick fingernails."
		
	elif usrcmd.lower() == ("get vines") and roomx == 3 and roomy ==4:
		lastmove = "You know nothing about viticulture, but even you can tell a lost cause when you see one."
		
	elif usrcmd.lower() == ("get poupe rot") and roomx == 3 and roomy == 4 and prmoss == 0 or usrcmd.lower() == ("get moss") and roomx == 3 and roomy == 4 and prmoss == 0:
		lastmove = "Ignoring JEAN TABARNAK's french mumblings, you kneel down and scrape off a foul dollop of POUPE ROT.  You add POUPE ROT to your INVENTORY."
		moss = moss + 1
		prmoss = 1	
		
	elif usrcmd.lower() == ("get growths") and roomx == 3 and roomy == 4 or usrcmd.lower() == ("get grapes") and roomx == 3 and roomy == 4 or usrcmd.lower() == ("look morbid growths") and roomx == 3 and roomy == 4:
		lastmove = "Those things would stink up yout inventory."
		
	elif usrcmd.lower() == ("get poupe rot") and roomx == 3 and roomy == 4 and prmoss == 1 or usrcmd.lower() == ("get moss") and roomx == 3 and roomy == 4 and prmoss == 1:
		lastmove = "You already have more than enough POUPE ROT in your INVENTORY.  You doubt your sheep will eat it anyway."
	
	elif usrcmd.lower() == ("talk jean") and roomx == 3 and roomy == 4 or usrcmd.lower() == ("talk jean tabarnak") and roomx == 3 and roomy == 4:
		lastmove = """He has a thick accent and speaks loudly, "Je ne comprends pas! Back en France ze south facing slope always produced the finest grapes.  Qu'est ce que je vais faire?" He turns to you, wringing his hands.  "These are the last of the famous Shitting-In-My-Own-Mouth grapes developed by mon grand père in the Deaux Deaux region before the great inconvenience. They can make exceptionnel wine, but here they do not grow." """
		
	elif usrcmd.lower() == ("map") and roomx == 3 and roomy == 4 and map == 1 or usrcmd.lower() == ("look map") and roomx == 3 and roomy == 4 and map == 1:
		lastmove = "You consult your map:"
		
		
#		
#		
#Room x4, y4  Swamp
	elif usrcmd.lower() == ("look") and roomx == 4 and roomy ==4 and guz == 0 and rat == 0:
		lastmove = "Before you the putresent bog meets the cold sea and contrives a wreched SWAMP.  It murmers flatulently.  A crooked SIGNPOST marks the area.  Everything is unacountably grey.   A metallic squawking issues from utop a jagged stone, whereupon sits a small green parrot named THE GUZ. “THE GUZ” says THE GUZ.  You are struck by the sickening solitude and eternal sadness of the place. "
		lastimage = "images/swamp_grt.gif"
		
	elif usrcmd.lower() == ("look") and roomx == 4 and roomy ==4 and guz != 0 and rat == 0:
		lastmove = "Before you the putresent bog meets the cold sea and contrives a wreched SWAMP.  It murmers flatulently.  A crooked SIGNPOST marks the area.  Everything is unacountably grey.  You are struck by the sickening solitude and eternal sadness of the place."
		lastimage = "images/swamp_grt.gif"
		
	elif usrcmd.lower() == ("look") and roomx == 4 and roomy ==4 and guz == 0 and rat >= 1:
		lastmove = "Before you the putresent bog meets the cold sea and contrives a wreched SWAMP.  It murmers flatulently.  A crooked SIGNPOST marks the area.  Everything is unacountably grey.   A metallic squawking issues from utop a jagged stone, whereupon sits a small green parrot named THE GUZ. “THE GUZ” says THE GUZ.  You are struck by the sickening solitude and eternal sadness of the place. "
		lastimage = "images/swamp_gt.gif"
		
	elif usrcmd.lower() == ("look") and roomx == 4 and roomy ==4 and guz != 0 and rat >= 1:
		lastmove = "Before you the putresent bog meets the cold sea and contrives a wreched SWAMP.  It murmers flatulently.  A crooked SIGNPOST marks the area.  Everything is unacountably grey.  You are struck by the sickening solitude and eternal sadness of the place."
		lastimage = "images/swamp_gt.gif"
		
	elif usrcmd.lower() == ("map") and roomx == 4 and roomy == 4 and map == 1 or usrcmd.lower() == ("look map") and roomx == 4 and roomy == 4 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x4y4.gif"
		
	elif usrcmd.lower() == ("look the guz") and roomx == 4 and roomy ==4 and guz == 0:
		lastmove = """THE GUZ is a small green parrot whose smug, bulbous eyes protrude from their sockets as if in flight from the skull itself.  She peers down at you before squonking "HELLO" and dropping a turd."""

	elif usrcmd.lower() == ("look the guz") and roomx == 4 and roomy ==4 and guz == 1:
		lastmove = "THE GUZ is in your inventory"
		
	elif usrcmd.lower() == ("look the guz") and roomx == 4 and roomy ==4 and guz >= 2:
		lastmove = "There is no The Gus to look at."
		
	elif usrcmd.lower() == ("talk the guz") and roomx == 4 and roomy ==4 and guz == 0:
		lastmove = """ "THE GUZ" says THE GUZ."""

	elif usrcmd.lower() == ("talk the guz") and roomx == 4 and roomy ==4 and guz == 1:
		lastmove = "THE GUZ is in your inventory"
		
	elif usrcmd.lower() == ("talk the guz") and roomx == 4 and roomy ==4 and guz >= 2:
		lastmove = "There is no The Gus to talk to."
		
	elif usrcmd.lower() == ("get the guz") and roomx == 4 and roomy ==4 and guz == 0:
		lastmove = """You reach one finger towards the bird and say "Step up, THE GUZ". The parrot declines the offered finger and takes a seat on your shoulder.  THE GUZ is added to your INVENTORY."""
		guz = 1
		
	elif usrcmd.lower() == ("get the guz") and roomx == 4 and roomy ==4 and guz == 1:
		lastmove = "THE GUZ is in your INVENTORY."
		
	elif usrcmd.lower() == ("get the guz") and roomx == 4 and roomy ==4 and guz >= 2:
		lastmove = "There in no The Guz to get."
	
	elif usrcmd.lower() == ("look swamp") and roomx == 4 and roomy ==4 and tisdale == 0:
		lastmove = "A vast expance of placidly churning substance, like a quagmire of aggregate expectorations.  Likely the result of recent glacial melt. A leathery APPENDAGE floats amidst the rotting plant matter."

	elif usrcmd.lower() == ("look swamp") and roomx == 4 and roomy ==4 and tisdale != 0:
		lastmove = "A vast expance of placidly churning substance, like a quagmire of aggregate expectorations.  Likely the result of recent glacial melt."

	elif usrcmd.lower() == ("look appendage") and roomx == 4 and roomy ==4 and tisdale == 0:
		lastmove = "Is it a piece of driftwood? An arm? There’s only one way to know."

	elif usrcmd.lower() == ("look appendage") and roomx == 4 and roomy ==4 and tisdale != 0:
		lastmove = "There is no appendage to see."
		
	elif usrcmd.lower() == ("get appendage") and roomx == 4 and roomy ==4 and tisdale == 0:
		lastmove = "You reach into the muck and pull on the leathery appendage. Out comes the dark, shriveled mummy of Mrs. Tisdale. You note the scratches left by talons and beaks that cover her forearms, marking where she had been gripped by the vultures that had carried her away. You add MRS. TISDALE to your INVENTORY."
		tisdale = 1

	elif usrcmd.lower() == ("get appendage") and roomx == 4 and roomy ==4 and tisdale != 0:
		lastmove = "There is no appendage to get."

	elif usrcmd.lower() == ("look signpost") and roomx == 4 and roomy == 4 and rat == 0 or usrcmd.lower() == ("look sign") and roomx == 4 and roomy == 4 and rat == 0:
		lastmove = """The inscription on the blasted sign is partially obscured by a thick layer of grey lichen. It reads “Wretched SWAMP”. A dead RAT swings listlessly in the stiff wind, suspended from the sign by a thick cord. You wonder how that got there."""
		
	elif usrcmd.lower() == ("look signpost") and roomx == 4 and roomy == 4 and rat == 1 or usrcmd.lower() == ("look sign") and roomx == 4 and roomy == 4 and rat != 0:
		lastmove = """The inscription on the blasted sign is partially obscured by a thick layer of grey lichen. It reads “Wretched SWAMP”."""

	elif usrcmd.lower() == ("get signpost") and roomx == 4 and roomy == 4 or usrcmd.lower() == ("get sign") and roomx == 4 and roomy == 4:
		lastmove = "It is stuck deep into the mud, well beyond your effort."
		
	elif usrcmd.lower() == ("look rat") and roomx == 4 and roomy == 4 and rat == 0:
		lastmove = "Gross"
		
	elif usrcmd.lower() == ("look rat") and roomx == 4 and roomy == 4 and rat == 1:
		lastmove = "You can not see the RAT in your INVENTORY."
		
	elif usrcmd.lower() == ("look rat") and roomx == 4 and roomy == 4 and rat == 2:
		lastmove = "You gave the rat to some child."

	elif usrcmd.lower() == ("get rat") and roomx == 4 and roomy == 4 and rat == 0:
		lastmove = "You gently tug on the RAT, and the rotten cord seperates from the SIGNPOST, you place in your pocket. RAT has been added to your INVENTORY."
		rat = 1
		lastimage = "images/swamp_gt.gif"
		
	elif usrcmd.lower() == ("get rat") and roomx == 4 and roomy == 4 and rat == 1:
		lastmove = "The RAT is already in your INVENTORY."
		
	elif usrcmd.lower() == ("get rat") and roomx == 4 and roomy == 4 and rat == 2:
		lastmove = "You already gave the rat to some child."
		
	elif usrcmd.lower() == ("look grey lichen") and roomx == 4 and roomy == 4:
		lastmove = "It's not moss, if that's what you were hoping."

	elif usrcmd.lower() == ("get grey lichen") and roomx == 4 and roomy == 4:
		lastmove = "You have no need."

		
########## y5 ##########
#		
#Room x1, y5		Thora
	elif usrcmd.lower() == ("look") and roomx == 1 and roomy ==5 and rat <= 1:
		lastmove = "The ground at the base of a glacial erratic is almost entirely composed of mud. A CHILD before you pants and hoots, rooting in the mud, mouth and chin covered in a thick layer of partially dried library PASTE. She periodically stirs the PASTE with apparent delight."
		lastimage = "images/mossquest.gif"
		
	elif usrcmd.lower() == ("look") and roomx == 1 and roomy ==5 and rat == 2:
		lastmove = "The ground at the base of a glacial erratic is almost entirely composed of mud. A CHILD before you pants and hoots, she crudely tossed aside the jar of PASTE, which lies on its side, its contents intermingling with the muck. She sure is enjoying that rat."
		lastimage = "images/mossquest.gif"
		
	elif usrcmd.lower() == ("map") and roomx == 1 and roomy == 5 and map == 1 or usrcmd.lower() == ("look map") and roomx == 1 and roomy == 5 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x1y5.gif"
		
	elif usrcmd.lower() == ("look child") and roomx == 1 and roomy ==5 and rat <= 1:
		lastmove = "The CHILD squats in the mud beneath the enormous rock, rooting with one arm deep in a ceramic jar of library PASTE. You see that she is downing PASTE at an unwholesome rate, scooping great quantities of the goo from the pot to her gaptooth maw. The PASTE squelches. She does not close her mouth to chew."
		
	elif usrcmd.lower() == ("look child") and roomx == 1 and roomy ==5 and rat == 2:
		lastmove = "The CHILD swings the rat against the glacial erratic behind her, sending limbs and organs flying. She hoots with pleasure."
		
	elif usrcmd.lower() == ("talk child") and roomx == 1 and roomy ==5 and rat <= 1:
		lastmove = "She ululates and gestures at the glacial erratic, pounding the stone with one hand and the muck with the other."
		
	elif usrcmd.lower() == ("talk child") and roomx == 1 and roomy ==5 and rat == 2:
		lastmove = "She gesticulates with, and at the rat. Its entrails litter the ground about her. Spying a diminutive liver, she seems to take great relish in grinding the organ into the muck with her groty foot."

	elif usrcmd.lower() == ("get child") and roomx == 1 and roomy ==5:
		lastmove = "Adopting a CHILD is a big responsibility.  Between caring for your mother Gurtha, and your small flock of sheep, you can't imagine taking on more right now."

	elif usrcmd.lower() == ("give rat") and roomx == 1 and roomy ==5 and rat == 0:
		lastmove = "You have no rat to give"
		
	elif usrcmd.lower() == ("give rat") and roomx == 1 and roomy ==5 and rat == 1:
		lastmove = "You pull the rat from your pocket and give the cord a swing. The rat describes a small arc in the air between you and the child, who sits transfixed, eyes following the moldy rodent in its semicircular path. She snatches the dead animal from the air and begins dragging the creature to and fro with great gusto. Pausing briefly to root about in the muck with one hand, the girl pulls a wad of green moss from the filth, which she tosses in your direction. You add BRYOLOGIST’S DREAM to your INVENTORY."
		rat = 2
		moss = moss + 1
		bdmoss = 1	
		
	elif usrcmd.lower() == ("look paste") and roomx == 1 and roomy ==5:
		lastmove = "In a large ceramic jar, it is off white and sticking to everything.  You are unsure why anybody would need such a large jar of PASTE."

	elif usrcmd.lower() == ("get paste") and roomx == 1 and roomy ==5:
		lastmove = "The child coddles it protectively."

	elif usrcmd.lower() == ("look mud") and roomx == 1 and roomy ==5:
		lastmove = "It looks muddy."

	elif usrcmd.lower() == ("look glacial erratic") and roomx == 1 and roomy ==5:
		lastmove = "It kind of looks like a rubber duck."
		
	elif usrcmd.lower() == ("get glacial erratic") and roomx == 1 and roomy ==5:
		lastmove = "You're being an idiot."
		
	elif usrcmd.lower() == ("give smokes") and roomx == 1 and roomy ==5 and smokes == 1:
		lastmove = "She's a child, that's just irresponsible."
		
#		
#		
#Room x2, y5        parrotman
	elif usrcmd.lower() == ("look") and roomx == 2 and roomy ==5:
		lastmove = "On the ascent to the summit of Mossfell Peak, you come upon a stone cottage.  You let yourself in through its front door, neglecting to use its great brass knocker. Inside a sweatband and short shorts bedecked MAN shvitzes, leaping and gyrating to recreate the frantic motions called for by the aerobics instructor howling from an ancient vinyl phonograph player."
		lastimage = "images/mossquest.gif"
		
	elif usrcmd.lower() == ("map") and roomx == 2 and roomy == 5 and map == 1 or usrcmd.lower() == ("look map") and roomx == 2 and roomy == 5 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x2y5.gif"
		
	elif usrcmd.lower() == ("look phonograph") and roomx == 2 and roomy ==5 or usrcmd.lower() == ("look phonograph player") and roomx == 2 and roomy ==5:
		lastmove = "It is one of those old wind up styles, must have been a serious effort to get it down here."
		
	elif usrcmd.lower() == ("get phonograph") and roomx == 2 and roomy ==5 or usrcmd.lower() == ("get phonograph player") and roomx == 2 and roomy ==5:
		lastmove = "This MAN is clearly using it."
				
	elif usrcmd.lower() == ("look man") and roomx == 2 and roomy ==5 and bird == 0:
		lastmove = "He is moist as a cold piece of fruit left in the heat. A poof of red hair, slicked back into a cylinder by his sweatband, jiggles suggestively atop his head. He quenches himself with a BOTTLE of brackish water.  In spite of his spirited movements, his countenance is forlorn."

	elif usrcmd.lower() == ("look man") and roomx == 2 and roomy ==5 and bird == 1:
		lastmove = "He is moist as a cold piece of fruit left in the heat. A poof of red hair, slicked back into a cylinder by his sweatband, jiggles suggestively atop his head.  He quenches himself with a BOTTLE of brackish water.  THE GUZ sits upon his hair."
		
	elif usrcmd.lower() == ("look man") and roomx == 2 and roomy ==5 and bird == 2:
		lastmove = "He is moist as a cold piece of fruit left in the heat. A poof of red hair, slicked back into a cylinder by his sweatband, jiggles suggestively atop his head.  He quenches himself with a BOTTLE of brackish water.  THE GUS sits upon his hair."
		
	elif usrcmd.lower() == ("talk man") and roomx == 2 and roomy ==5 and bird == 0:
		lastmove = """He immediately ceases his exaggerated movement and turns to you with both palms planted on the side of his head in consternation. "My The Guz! My The Guz! Have you seen my The Guz?" He points to an empty birdcage sitting beside the TV. "My The Guz flew away just last Tuesday!" """
		
	elif usrcmd.lower() == ("talk man") and roomx == 2 and roomy ==5 and bird == 1:
		lastmove = """He briefly ceases his frantic movement and turns towards you. "A million thanks for returning my dear, sweet The Guz!". The disembodied voice of the fitness instructor warps and deepens as the record slows and the man moves to give the stopped machine a crank."""
		
	elif usrcmd.lower() == ("look the guz") and roomx == 2 and roomy ==5 and bird == 1:
		lastmove = "The MAN continues his vigorous calisthenics routine as his recently returned The Guz hangs on his left shoulder for dear life."
	
	elif usrcmd.lower() == ("talk man") and roomx == 2 and roomy ==5 and bird == 2:
		lastmove = "XXX"
		
	elif usrcmd.lower() == ("give the gus") and roomx == 2 and roomy ==5 and gus == 1 and bird == 0:
		lastmove = """Revealing the small, plump bird to the sweaty calisthenics enthusiast, he peers at it with interest, squinting as if something isn’t quite right, which it isn’t. "THE GUS" proclaims The Gus, in a tinny voice. The man frowns and gesticulates at the ceiling. "You idiot, this isn’t my The Guz, this is some kind of washed up The Gus!" He resumes his aerobics with a huff.  You are stuck with your THE GUS"""
		#gus = 2
		#bird = 2
		
	elif usrcmd.lower() == ("give the gus") and roomx == 2 and roomy ==5 and gus != 1:
		lastmove = "You do not have a The Gus to give."
		
	elif usrcmd.lower() == ("give the gus") and roomx == 2 and roomy ==5 and gus == 1 and bird == 1:
		lastmove = "He seems pretty content with his THE GUZ."
		
	elif usrcmd.lower() == ("give the guz") and roomx == 2 and roomy ==5 and guz == 1 and bird == 0:
		lastmove = """You wave to the exercising man and point to the bug eyed bird on your shoulder. "THE GUZ" squonks The Guz. The man puts both palms to his cheeks with joy as his avian companion flaps to his shoulder and promptly begins chewing his saturated sweatband. He reaches into the pocket of his shvitzy short shorts and hands you a handsome specimen of PARROTMAN’S LIVERWORT. You add PARROTMAN’S LIVERWORT to your INVENTORY."""
		guz = 2
		bird = 1
		pmlwmoss = 1
		moss = moss + 1

	elif usrcmd.lower() == ("give the guz") and roomx == 2 and roomy ==5 and guz != 1:
		lastmove = "You don't have a The Guz to give."
		
	elif usrcmd.lower() == ("give the guz") and roomx == 2 and roomy ==5 and guz == 1 and bird == 2:
		lastmove = "You feel uncomfortable giving the man another bird."
		
	elif usrcmd.lower() == ("look bottle") and roomx == 2 and roomy ==5:
		lastmove = """It appears to be a BOTTLE of Fennelated water.  Somebody thought fennel infused water was a good idea.  You can still recall the slogan from years ago "Fennelated water: it’s good for you because it’s gross!" """
		
	elif usrcmd.lower() == ("get bottle") and roomx == 2 and roomy ==5:
		lastmove = "You absolutely don't need that."
	
	
	
		
#		
#		
#Room x3, y5		Mossfell peak
	elif usrcmd.lower() == ("look") and roomx == 3 and roomy ==5:
		lastmove = "You reach the craggy summit of Mossfell.  Below you is the entire Keller Penninsula.  Above you, an equally substancial leaden twilight.  Atop a jagged boulder stands some kind of WIZARD surveying the vista."
		lastimage = "images/mossfellpeak.gif"
		
	elif usrcmd.lower() == ("map") and roomx == 3 and roomy == 5 and map == 1 or usrcmd.lower() == ("look map") and roomx == 3 and roomy == 5 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x3y5.gif"
		
	elif usrcmd.lower() == ("look wizard") and roomx == 3 and roomy == 5 and loudandy == 0:
		lastmove = "The WIZARD alternates between digging in his pockets and diddling an aged Boston Red Sox branded disposable LIGHTER. His robes are blacker than black."
		
	elif usrcmd.lower() == ("look wizard") and roomx == 3 and roomy == 5 and loudandy != 0:
		lastmove = "He sucks down his last cigerette and proceeds to continue alternating between digging in his pockets and worrying a Boston Red Sox branded disposable lighter. His robes are blacker than black."
		
	elif usrcmd.lower() == ("talk wizard") and roomx == 3 and roomy == 5 and loudandy == 0:
		lastmove = """He looks at you pissily, kneading his forehead and says “No one’s getting any magic 'round here ‘til Mikey gets his smokes." """
		
	elif usrcmd.lower() == ("talk wizard") and roomx == 3 and roomy == 5 and loudandy != 0:
		lastmove = "I’ma fackin’ warlock ya know dood!"
		
	elif usrcmd.lower() == ("give smokes") and roomx == 3 and roomy == 5 and smokes != 1:
		lastmove = "You don't have any smokes to give."
		
	elif usrcmd.lower() == ("give smokes") and roomx == 3 and roomy == 5 and smokes == 1 and loudandy == 0:
		lastmove = """You hand the WIZARD a pack of smokes and he gratefully lights up. He turns to you and says “You wanna get ridda that fackin’ demon, kid? Boy do I gotta an incantation f’you. You just gotta say: You will not get away with this LOUD ANDY!” You add this incantation to your INVENTORY."""
		smokes = 2
		loudandy = 1
		
	elif usrcmd.lower() == ("look lighter") and roomx == 3 and roomy == 5:
		lastmove = "It's well worn, the plastic has bleached and cracked with age."
		
	elif usrcmd.lower() == ("get lighter") and roomx == 3 and roomy == 5:
		lastmove = "You fear incurring the mosterous evil arts of the WIZARD, you do not get the LIGHTER."

		
		
#		
#		
#Room x4, y5		Graveyard
	elif usrcmd.lower() == ("look") and roomx == 4 and roomy ==5:
		lastmove = "You stand in the old Mossfell graveyard.  GREGBERRIES carpet the muddy ground,  The damp, warming soil is releasing smells and memories lodged deep within the permafrost.  It's kind of gross.  As far as you can tell only one GRAVESTONE has a legible inscription."
		lastimage = "images/mossquest.gif"
		
	elif usrcmd.lower() == ("look gravestone") and roomx == 4 and roomy ==5 and blmoss == 0:
		lastmove = "While the other gravestones have been eroded by the ceasless Antatctic winds, a comparatively new one reads: "
		
	elif usrcmd.lower() == ("look gravestone") and roomx == 4 and roomy ==5 and blmoss == 1:
		lastmove = "XXX[Burpo's Liverwort will be added here]"
		
	elif usrcmd.lower() == ("get gravestone") and roomx == 4 and roomy ==5:
		lastmove = "XXX"
		
	elif usrcmd.lower() == ("look burpo's liverwort") and roomx == 4 and roomy ==5 and blmoss == 0 or usrcmd.lower() == ("look burpos liverwort") and roomx == 4 and roomy ==5 and blmoss == 0 or usrcmd.lower() == ("look liverwort") and roomx == 4 and roomy ==5 and blmoss == 0:
		lastmove = "XXX"
		
	elif usrcmd.lower() == ("get burpo's liverwort") and roomx == 4 and roomy ==5 and blmoss == 0 or usrcmd.lower() == ("get burpos liverwort") and roomx == 4 and roomy ==5 and blmoss == 0 or usrcmd.lower() == ("get liverwort") and roomx == 4 and roomy ==5 and blmoss == 0:
		lastmove = "Burpo's Liverwort has been added to your INVENTORY"	
		moss = moss + 1
		blmoss = 1
		
	elif usrcmd.lower() == ("look gregberries") and roomx == 4 and roomy ==5:
		lastmove = "You can't quite pin down why, but these berries truly look like small, corpulent Gregs.  You aren't even sure if you've ever met a Greg."
	
	elif usrcmd.lower() == ("get gregberries") and roomx == 4 and roomy ==5 and gregberries == 0:
		lastmove = "You gently pick the fleshy, red berries from their stalks, until a healthy handful has been heaped.  GREGBERRIES have been added to your INVENTORY."
		gregberries = 1
		
	elif usrcmd.lower() == ("get gregberries") and roomx == 4 and roomy ==5 and gregberries != 0:
		lastmove = "You have already taken your share of GREGBERRIES"
		
	elif usrcmd.lower() == ("map") and roomx == 3 and roomy == 5 and map == 1 or usrcmd.lower() == ("look map") and roomx == 3 and roomy == 5 and map == 1:
		lastmove = "You consult your map:"	
		lastimage = "maps/x4y5.gif"
		
		
		
		
		
		
		
########## y6 ##########
#		
#Room x1, y6 Glacial drip
	elif usrcmd.lower() == ("look") and roomx == 1 and roomy == 6 and stmoss == 0:
		lastmove = "You stand in the shadow of the glacier, gentle cascades of limpid water spit over your head and shoulders.  You see a patch of SMOLENSK TEA emerging from the mud.  An atavistic dread wells within you."
		lastimage = "images/mossquest.gif"
		
	elif usrcmd.lower() == ("look") and roomx == 1 and roomy == 6 and stmoss == 1:
		lastmove = "You stand in the shadow of the glacier, gentle cascades of limpid water spit over your head and shoulders.  An atavistic dread wells within you."
		lastimage = "images/mossquest.gif"
		
	elif usrcmd.lower() == ("map") and roomx == 1 and roomy == 6 and map == 1 or usrcmd.lower() == ("look map") and roomx == 1 and roomy == 6 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x1y6.gif"
		
	elif usrcmd.lower() == ("look smolensk tea") and roomx == 1 and roomy == 6:
		lastmove = "SMOLENSK TEA is a native moss that the Bellingshausiens praise highly.  You recall what a treat it was when your ailing mother Gurtha made you a steaming mug of earthy SMOLENSK TEA after a long day of shearing the sheep."

	elif usrcmd.lower() == ("get smolensk tea") and roomx == 1 and roomy == 6 and stmoss == 0:
		lastmove = "You break off a piece and smell the farmilair, earthy aroma.  SMOLENSK TEA added to your INVENTORY."
		moss = moss + 1
		stmoss = 1
	
	elif usrcmd.lower() == ("get smolensk tea") and roomx == 1 and roomy == 6 and stmoss == 1:
		lastmove = "You already have SMOLENSK TEA in your INVENTORY."
		
#		
#		
#Room x2, y6		Santa
	elif usrcmd.lower() == ("look") and roomx == 2 and roomy == 6:
		lastmove = "You come upon a rotted out sleigh that has been turned on its back, its runners facing skyward in emulation of an animal stuck on its back. An assortment of boards of varying lengths prop up one side of the ruined craft, and you realize that it has been fashioned into the crudest of HOVELS. A stout MAN huddles in the gloom of the rough-hewn shelter."
		lastimage = "images/mossquest.gif"
			
	elif usrcmd.lower() == ("look man") and roomx == 2 and roomy == 6:
		lastmove = "You peer into the musty darkness of the HOVEL, and its inhabitant peers back with eyes weary and guarded. He wears a curious red suit trimmed with white fur, its once grand tailoring now tainted by mildew and wear that has left it threadbare and torn. Beneath a matching cap sit two red eyes suspended above a tangled white beard. The sight of this MAN stirs a feeling in you not unlike that of nearly remembering a word or name, as if your mind strains to place him somewhere in long-ago memory. You look at him. He looks at you. Silence sits between you."
		
	elif usrcmd.lower() == ("look hovel") and roomx == 2 and roomy == 6 or usrcmd.lower() == ("look hovels") and roomx == 2 and roomy == 6:
		lastmove = "It is clear that this rough approximation of a human habitation was once a beautifully crafted sleigh. Its runners are devoured by a thick coating of orange rust, and its body is a patchwork of dark, rotted wood and grey lichen."
		
	elif usrcmd.lower() == ("talk man") and roomx == 2 and roomy == 6 and rdmoss != 1:
		lastmove = """ “A young one.” He says, eyeing you from the dark of his crude home. “One too young to properly remember the catastrophe that befell the world into which you were blamelessly born. Too young to know the wonders of that departed world but old enough to hear of them endlessly from three generations of mortified elders.” He shifts uncomfortably in the gloom.  “Young enough to know me perhaps? I cannot say. Fewer and fewer of the unfortunates who make it this far south recognize me. Those that do know me as an avatar of that prosperous time, the embodiment of a brief, shining, era before darkness engulfed humankind oncemore.” He pauses and moves forward towards the front of the structure, now looking you in the eye.  “Have you any idea of the principle that I embodied in those times? Which tied the gain of material goods with the moral good? No, then how could you understand the horror of the disintegration of such an ethic, when the powerful furiously consolidated and leveraged their wealth and the masses understood, finally, that they’d been sold a bill of lies? Have you any idea of the moral and material chaos of those times? Or that we have reached an epoch beyond good and evil? I will impart on you the wisdom that it has taken me three hundred grim years to fully fathom: that man’s actions have no correlate with his worldly reward.”   He hands you a spring of REINDEER MOSS through the gloom and speaks no more.   REINDEER MOSS is added to your INVENTORY."""
		rdmoss = 1
		moss = moss + 1

	elif usrcmd.lower() == ("talk man") and roomx == 2 and roomy == 6 and rdmoss == 1:
		lastmove = "He speaks no more."
		
	elif usrcmd.lower() == ("give cold one") and roomx == 2 and roomy == 6 and coldone == 1:
		lastmove = "He leaps forward and promptly shotguns the whole thing. Beer drips frothily from his white beard."
		coldone = 0
		
	elif usrcmd.lower() == ("map") and roomx == 2 and roomy == 6 and map == 1 or usrcmd.lower() == ("look map") and roomx == 2 and roomy == 6 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x2y6.gif"
		
#		
#		
#Room x3, y6	Buttswood
	elif usrcmd.lower() == ("look") and roomx == 3 and roomy == 6 and branch == 0:
		lastmove = "On the sheltered north face of Mt. Mossfell you find several gnarled, stunted bushes.  The locals on the nearby moor call it the BUTTSWOOD, ironically you hope.  A blunt BRANCH, hanging invitingly catches your eye."
		lastimage = "images/mossquest.gif"
	
	elif usrcmd.lower() == ("look branch") and roomx == 3 and roomy == 6 and branch == 0:
		lastmove = "This would be great for beating up penguins, if that's something you'd like to do."
		
	elif usrcmd.lower() == ("get branch") and roomx == 3 and roomy == 6 and branch == 0:
		lastmove = "Feeling like a mutton-witted brute, you break the BRANCH from the stunted tree that sprouted it. BRANCH is added to your INVENTORY."
		branch = 1
		
	elif usrcmd.lower() == ("map") and roomx == 3 and roomy == 6 and map == 1 or usrcmd.lower() == ("look map") and roomx == 3 and roomy == 6 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x3y6.gif"
		
		
#		
#		
#Room x4, y6	Monsters
	elif usrcmd.lower() == ("look") and roomx == 4 and roomy == 6:
		lastmove = "In the shadow of the glacier, hiding from the dispassionate moon you see CREATURES hardly more corporeal than a shadow."
		lastimage = "images/mossquest.gif"
		
	elif usrcmd.lower() == ("look creature") and roomx == 4 and roomy == 6 or usrcmd.lower() == ("look creatures") and roomx == 4 and roomy == 6:
		lastmove = "Man’s evil art has raised this eldritch monster. Temperatures rose and they emerged from the the brackish, primordial slime of the permafrost melt. An atavistic beast forgotten even in our nightmares, lost in the great, frozen morass, for uncountable millennia.  They are before you now, their forms are indistinct, they sulk and pulsate and seem to be oozing darkness itself.  You presume they are sinister omens.  The darkness grows."
		lookcreature = 1
		
	elif usrcmd.lower() == ("talk creature") and roomx == 4 and roomy == 6 or usrcmd.lower() == ("talk creatures") and roomx == 4 and roomy == 6:
		lastmove = "They quietly emit indistinct, raspy wispers.  You can not dicipher any language or meaning.  You move back uncomforrtably."
		lookcreature = 1

	elif usrcmd.lower() == ("map") and roomx == 4 and roomy == 6 and map == 1 or usrcmd.lower() == ("look map") and roomx == 4 and roomy == 6 and map == 1:
		lastmove = "You consult your map:"
		lastimage = "maps/x4y6.gif"



#####################################basic functions#####################################

	elif usrcmd.lower() == ("direrrnorth"): #you can't go north because glacier
		lastmove = "You can not go north.  You gaze up at the black comfortless sky; steep glacial cliffs block the way ahead."
		
	elif usrcmd.lower() == ("direrrbog"): #you can't go north because bog
		lastmove = "Before you lays a putresent bog formed from chill glacial melt.  You have heard stories about it consuming people and sheep indescriminately.  Perhaps with the right equipment, you could pass, but as is, you dare not attempt."

	elif usrcmd.lower() == ("direrreast"): #you can't go east
		lastmove = "The unknowable black depths of the water perturb you.  You decide not to go east."
		
	elif usrcmd.lower() == ("direrrsouth"): #you can't go south
		lastmove = "Inky, cold Admiralty bay lies to your south, the frigid water is best avoided."

	elif usrcmd.lower() == ("direrrwest"): #you can't go west
		lastmove = "You are not prepared to swim."
		
	elif usrcmd.lower() == ("score"): #for testing only
		lastmove = ("Current score: {}").format(moss)

	elif usrcmd.lower() == ("give map") and map == 1:
		lastmove = "That thing is way too useful, you're not about to give that away."
		
	elif usrcmd.lower() == ("inventory") or usrcmd.lower() == ("inv"):
		if gcmoss == 1: 
			gcmossinv = "\n  Gundy's Carpet"
		if bdmoss == 1:
			bdmossinv = "\n  Bryologist's Dream"
		if dpmoss == 1: 
			dpmossinv = "\n  Diaper Peat"
		if bsmoss == 1: 
			bsmossinv = "\n  Brundled Sphagnum"
		if gsmoss == 1: 
			gsmossinv = "\n  Giuseppe's Shag"
		if mpdmoss == 1: 
			mpdmossinv = "\n  Mudpuppy's Duvet"
		if rdmoss == 1: 
			rdmossinv = "\n  Reindeer Moss"
		if pmlwmoss == 1: 
			pmlwmossinv = "\n  Parrotman's Liverwart"
		if bbmoss == 1: 
			bbmossinv = "\n  Bungled Brown Moss"
		if stmoss == 1: 
			stmossinv = "\n  Smolensk Tea"
		if bbrmoss == 1: 
			bbrmossinv = "\n  Bushman's Bog Roll"
		if blmoss == 1: 
			blmossinv = "\n  Burpo's Liverwort"
		if prmoss == 1: 
			prmossinv = "\n  Poupe Rot"
			
			
			
		if smokes == 1: 
			smokesinv = "\n  A pack of SMOKES"
		elif smokes != 1:
			smokesinv = ""
		if loudandy == 1: 
			incantationinv = "\n  An INCANTATION to expel Loud Andy"
		elif loudandy != 1:
			incantationinv = ""
		if diaper == 1: 
			diaperinv = "\n  A handsome sheerling lined DIAPER"
		elif diaper == 0:
			diaperinv = ""
		if snails == 1: 
			snailsinv = "\n  A bagful of SNAILS"
		elif snails == 0:
			snailsinv = ""
		if penguinquest == 1: 
			penguininv = "\n  A greasy sack"
		elif penguinquest == 2: 
			penguininv = "\n  A greasy sack with a PENGUIN in it"
		elif penguinquest == 0 or penguinquest == 3:
			penguininv = ""	
		if rat == 1: 
			ratinv = "\n  A RAT and a string to swing it with"
		elif rat != 1:
			ratinv = ""
		if tisdale == 1: 
			tisdaleinv = "\n  MRS. TISDALE's body"
		elif tisdale != 1:
			tisdaleinv = ""
		if apple == 1: 
			appleinv = "\n  A small russet APPLE"
		elif apple != 1:
			appleinv = ""
		if map == 1: 
			mapinv = "\n  A MAP of Mossfell"
		elif map != 1:
			mapinv = ""
		if snowshoes == 1: 
			snowshoesinv = "\n  A pair of SNOWSHOES"
		elif snowshoes != 1:
			snowshoesinv = ""
		if chum == 1: 
			chuminv = "\n  A fistful of CHUM"
		elif chum != 1:
			chuminv = ""
		if coldone == 1: 
			coldoneinv = "\n  A frosty COLD ONE"
		elif coldone != 1:
			coldoneinv = ""	
		if guz == 1: 
			guzinv = "\n  THE GUZ"
		elif guz != 1:
			guzinv = ""	
		if gus == 1: 
			gusinv = "\n  THE GUS"
		elif gus != 1:
			gusinv = ""	
		if egg == 1: 
			egginv = "\n  A penguin EGG"
		elif egg != 1:
			egginv = ""	
		if branch == 1: 
			branchinv = "\n  A blunt BRANCH"
		elif branch != 1:
			branchinv = ""	
		if gregberries == 1: 
			gregberriesinv = "\n  A serving of GREGBERRIES"
		elif gregberries != 1:
			gregberriesinv = ""				
		
		
		
		
			
		lastmove = ("Mosses:{}{}{}{}{}{}{}{}{}{}{}{}{}\nInventory:{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}{}").format(gcmossinv, rdmossinv, bdmossinv, dpmossinv, bsmossinv, gsmossinv, mpdmossinv, pmlwmossinv, bbmossinv, stmossinv, bbrmossinv, blmossinv, prmossinv, mapinv, smokesinv, incantationinv, diaperinv, snailsinv, penguininv, ratinv, tisdaleinv, appleinv, snowshoesinv, chuminv, coldoneinv, guzinv, gusinv, egginv, branchinv, gregberriesinv)

	elif usrcmd.lower() == ("help"):
		lastmove = """Subjects in CAPS can be interacted with. Possible inputs:\nlook\nlook [subject]\nget [subject]\ntalk [subject]\ngive [object in inventory]\ngo [north/east/south/west]\ninventory\nscore\nquit"""


	elif usrcmd.lower() == ("quit"):
		play = 0

	else:
		easygui.msgbox("""Command not understood, enter "help" for list of valid commands""")
		
	if moss == 10: #You win!
		easygui.msgbox(lastmove)
		easygui.msgbox("With your person brimming with diverse mosses, you feel your quest nearing completion.  You turn towards the port and tiredly drag your boat into the cold sea for the long journey back to your croft and your poor, aged mother.  Several hours pass, and rounding the final headland you think merrily on the comfort of home that awaits beyond. The warmth in your breast suddenly turns to ice as before you, where your small island once was, the measureless, black depths of the fjord stretch instead.  You see now that the glacier above has calved and bits of ice intermingle with the souvenirs of your life on the swelling surface of the water in this lovecraftian twilight.  As you lean upon the oars, feeling faint, you are struck by your singular, hopeless isolation.  A barbarous emptiness overcomes you.  You stare out over the crass vulgarity of the sea; a dismal wind blows.", ok_button="Proceed")
		easygui.msgbox("Congratulations, you have completed Moss Quest.")
		play = 0